# AppSentinels Sniffer Helm Chart

This Helm chart deploys the AppSentinels Sniffer as a DaemonSet on a Kubernetes cluster.

## Prerequisites

- Kubernetes
- Helm

## Installing the Chart

To install the chart with the release name `appsentinels-sniffer`:

```bash
helm install appsentinels-sniffer ./sniffer-sensor/helm-chart
```

The command deploys the AppSentinels Sniffer DaemonSet on the Kubernetes cluster with default configuration. The [Parameters](#parameters) section lists the parameters that can be configured during installation.

## Uninstalling the Chart

To uninstall/delete the `appsentinels-sniffer` deployment:

```bash
helm uninstall appsentinels-sniffer
```

## Parameters

The following table lists the configurable parameters of the AppSentinels Sniffer chart and their default values.

| Parameter                      | Description                                     | Default                               |
|--------------------------------|-------------------------------------------------|---------------------------------------|
| `nameOverride`                 | Override the name of the chart                  | `""`                                  |
| `fullnameOverride`             | Override the full name of the chart             | `""`                                  |
| `namespace`                    | Namespace to deploy the DaemonSet               | `appsentinels`                        |
| `image.repository`             | Image repository                                | `docker.io/appsentinels/ng-controller`|
| `image.tag`                    | Image tag                                       | `test`                                |
| `image.pullPolicy`             | Image pull policy                               | `Always`                              |
| `resources.limits.cpu`         | CPU resource limits                             | `2`                                   |
| `resources.limits.memory`      | Memory resource limits                          | `2Gi`                                 |
| `resources.requests.cpu`       | CPU resource requests                           | `1`                                   |
| `resources.requests.memory`    | Memory resource requests                        | `1Gi`                                 |
| `controller.serverName`        | Remote controller server name                   | `devsaas3.appsentinels.ai`            |
| `controller.serverPort`        | Remote controller server port                   | `9006`                                |
| `environment`                  | Environment setting                             | `dev`                                 |
| `sensorInstance`               | Sniffer sensor instance name                    | `dev-cluster-1-sensor`                |
| `tapInterface`                 | Network interface to tap                        | `all or any or default or interface-name`      |
| `tapFilter`                    | Tap filter expression                           | `tcp-and-port-8091`                   |
| `relayProtocol`                | Protocol for relay communication                | `http`                                |
| `tapProfile`                   | Tap profile setting                             | `low`                                 |
| `nodeSelector`                 | Node labels for pod assignment                  | `{}`                                  |
| `tolerations`                  | Tolerations for pod assignment                  | See values.yaml                       |

## TAP Interface

The `tapInterface` parameter can be set to `all` or `any` or `default` or an interface name.

- `all` - Tap all interfaces
- `any` - Tap local and ingress/egress interfaces
- `default` - Tap the default route interface
- `interface-name` - Tap a specific interface by name

## Example: Customizing the Installation

A YAML file that specifies the values for the parameters can be provided while installing the chart:

```bash
helm install appsentinels-sniffer ./sniffer-sensor/helm-chart -f values.yaml
```

Example `values.yaml`:

```yaml
environment: production
controller:
  serverName: prod.appsentinels.ai
  serverPort: 9006
sensorInstance: prod-cluster-sensor
tapFilter: tcp-and-not-port-443
resources:
  limits:
    cpu: 2
    memory: 4Gi
  requests:
    cpu: 1
    memory: 2Gi
```

## Upgrading the Chart

To upgrade the `appsentinels-sniffer` deployment:

```bash
helm upgrade appsentinels-sniffer ./sniffer-sensor/helm-chart
```

Or with custom values:

```bash
helm upgrade appsentinels-sniffer ./sniffer-sensor/helm-chart -f values.yaml
```

## Configuration Notes

### Node Selection

By default, the DaemonSet will run on all nodes in the cluster. To restrict it to specific nodes, you can use the `nodeSelector` parameter:

```yaml
nodeSelector:
  node-role.kubernetes.io/worker: "true"
```

### Privileged Mode

The sniffer sensor runs in privileged mode to access network interfaces. Ensure your cluster security policies allow privileged containers.

### Network Access

The DaemonSet uses `hostNetwork: true` to access the host's network stack directly. This is required for network traffic sniffing.

### Filtering for URI Extension, Hostname and Extension Filtering 
=============================================

These environment variables should be set in the container environment for your sniffer sensor

-------------------------------------------------------------------------------
#### skipHostnameRegex
-----------------------------
Purpose:

    Skip (exclude) HTTP transactions where the hostname matches this regular expression.

How it works:

    - If the regex matches the hostname, the transaction is SKIPPED (not logged)
    - If not set or empty, no hostnames are excluded by this filter.
    - Please note that this filter shouldnt be used with port numbers 

Example values:

    skipHostnameRegex="^www\.example\.com$"
        # Skips any transaction where the hostname is exactly 'www.example.com'

    skipHostnameRegex="(test|dev)\.mydomain\.org$"
        # Skips hostnames ending with 'test.mydomain.org' or 'dev.mydomain.org'


-------------------------------------------------------------------------------
#### includeHostnameRegex
-----------------------------------
Purpose:

    ONLY process (include) HTTP transactions where the hostname matches this regular expression.

How it works:

    - If set, ONLY hostnames matching this regex are processed.
    - If the hostname does NOT match, the transaction is skipped.
    - If not set or empty, all hostnames are included (unless excluded by skipHostnameRegex).
    - Please note that this filter shouldnt be used with port numbers 

Example values:

    includeHostnameRegex="^api\."
        # Only process hostnames starting with 'api.'

    includeHostnameRegex="(prod|main)\.mydomain\.org$"
        # Only process hostnames ending with 'prod.mydomain.org' or 'main.mydomain.org'


-------------------------------------------------------------------------------
#### uriExtentionFilter
-----------------------
Purpose:

    Skip (exclude) HTTP transactions where the URI path ends with one of the specified file extensions.

How it works:

    - If set, the value should be a '|' (pipe) separated list of file extensions (e.g., 'svg|png|jpg').
    - If the URI path ends with one of these extensions, the transaction is skipped.
    - If not set or empty, a default list of common static file extensions is used.

Default Extensions Skipped:

    "svg|txt|png|jpg|jpeg|io|tff|woff|woff2|ico|css|pdf|html|mp4|php|ajax|js|gif|tiff|ttf|docx|wasm|aspx"

Example values:

    uriExtentionFilter="svg|png|jpg|ico"
        # Skips URIs ending with .svg, .png, .jpg, or .ico

    uriExtentionFilter="js|css|woff2"
        # Skips URIs ending with .js, .css, or .woff2


--------------------------------
#### Order of Evaluation
-------------------
    1. If includeHostnameRegex is set, the hostname MUST match this regex to be processed.
    2. If skipHostnameRegex is set, the hostname MUST NOT match this regex to be processed.
    3. If uriExtentionFilter is set, the URI path MUST NOT end with one of the specified extensions.
    4. If both hostname regexes are set, the hostname must match the include regex AND must not match the skip regex.



-------------------------------------------------------------------------------
#### Regex Syntax and Escaping
-------------------------
    - Write regexes as you would in C or Python (e.g., ^foo\.bar$, .*\.test\.local$).
    - Use a single backslash (\.) for regex metacharacters.
    - When writing YAML (Kubernetes, Compose), you may need to double the backslash (\\.) for proper escaping.

-------------------------------------------------------------------------------
#### Examples for Kubernetes
-------------


```yaml
values.yaml:
  skipHostnameRegex: "^www\\.example\\.com$"
  includeHostnameRegex: "^api\\."
  uriExtentionFilter: "svg|png|jpg"
```
-------------------------------------------------------------------------------

Notes:
------
- All regexes are case-insensitive.
- If neither hostname regex is set, all hostnames are processed.
- If both hostname regexes are set, both conditions must be satisfied for a transaction to be processed.
- If uriExtentionFilter is not set, a default list of static file extensions is used.
