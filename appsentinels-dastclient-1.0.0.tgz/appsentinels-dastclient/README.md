## Deploying the AppSentinels DAST Client using Helm

### Prerequisites
- Ensure you have Helm installed on your system.
- Ensure you have access to the Kubernetes cluster where you want to deploy the AppSentinels DAST Client.
- Ensure you have `kubectl` configured to access your cluster.

### Security Configuration

The Helm chart supports two methods for handling the `SAAS_API_KEY_VALUE`:

#### Method 1: Direct Environment Variable (Default)
- **api_key** is defined directly in the `env` array in `values.yaml`
- This is the existing implementation - no changes needed for current users
- Simple and straightforward for development and testing environments

#### Method 2: External Kubernetes Secret (Recommended for Production)
- Uses an existing Kubernetes secret created with `kubectl create secret generic`
- Only requires specifying the secret `name` and `key`
- More secure for production environments
- Integrates with external secret management systems

**Important:** Never commit your actual API key to version control. Use environment variables or secure secret management tools in production.

### Configuration Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `useSaasKeyAsExternalSecret` | boolean | `false` | Set to `true` to use external Kubernetes secret |
| `externalSecret.name` | string | `"dast-client-secrets"` | Name of the existing Kubernetes secret |
| `externalSecret.key` | string | `"saas-api-key"` | Key within the secret that contains the api_key |

### Configuration Methods

#### Method 1: Direct Environment Variable (Default)

This method defines `api_key` directly in the `env` array in `values.yaml`. This is the existing implementation and requires no changes for current users.

**Configuration:**
```yaml
useSaasKeyAsExternalSecret: false  # Default value

env:
  - name: dast_client_tag
    value: "AppSentinels-created-org-name_dast_client"
  - name: saas_url
    value: "your-saas-server.appsentinels.ai"
  - name: api_key
    value: "your-appsentinels-api-key-here"
  - name: HTTPS_INSECURE_SKIP_VERIFY
    value: "true"
  #- name: aut_auth_https_proxy
  #  valuwe ""https://PROXY_IP:PORT"
  # -name: aut_https_proxy
  #  value: "https://PROXY_IP:PORT"
  # -name: dast_server_https_proxy
  #  value: "https://PROXY_IP:PORT"
```

**Deployment:**
```bash
helm install dast-client . -n appsentinels
```

#### Method 2: External Kubernetes Secret (Recommended for Production)

This method uses an existing Kubernetes secret created with `kubectl create secret generic`. The chart only references the secret by name and key.

**Step 1: Create the Kubernetes Secret**
```bash
kubectl create secret generic dast-client-secrets \
  --from-literal=saas-api-key="your-appsentinels-api-key-here" \
  -n appsentinels
```

**Step 2: Configure the Chart**
```yaml
useSaasKeyAsExternalSecret: true
externalSecret:
  name: "dast-client-secrets"  # Name of the existing Kubernetes secret
  key: "saas-api-key"  # Key within the secret

# ⚠️ Do **not** define `SAAS_API_KEY_VALUE` in the `env` section below when `useSaasKeyAsExternalSecret: true`. The value will be sourced from the referenced Kubernetes secret.

env:
  - name: dast_client_tag
    value: "AppSentinels-created-org-name_dast_client"
  - name: saas_url
    value: "your-saas-server.appsentinels.ai"
  - name: HTTPS_INSECURE_SKIP_VERIFY
    value: "true"
  #- name: aut_auth_https_proxy
  #  valuwe ""https://PROXY_IP:PORT"
  # -name: aut_https_proxy
  #  value: "https://PROXY_IP:PORT"
  # -name: dast_server_https_proxy
  #  value: "https://PROXY_IP:PORT"  
```

**Step 3: Deploy**
```bash
helm install dast-client . -n appsentinels
```

### Deployment as Standalone Controller

> Service (9004) --> Deployment (port 9004)

#### Initial Setup

1. Create the `appsentinels` namespace:
    ```sh
    kubectl create namespace appsentinels
    ```


#### Steps

1. Navigate to the directory containing the Helm chart:

2. Review and update the `values.yaml` file to configure the deployment according to your requirements.

    **Method 1: Direct Environment Variable (Default):**
    ```yaml
    useExternalSecret: false

    env:
      - name: dast_client_tag
        value: "AppSentinels-created-org-name_dast_client"
      - name: saas_url
        value: "your-saas-server.appsentinels.ai"
      - name: api_key
        value: "your-appsentinels-api-key-here"
      - name: HTTPS_INSECURE_SKIP_VERIFY
        value: "true"  # Set to true if using self-signed certificates
      #- name: aut_auth_https_proxy
      #  valuwe ""https://PROXY_IP:PORT"
      # -name: aut_https_proxy
      #  value: "https://PROXY_IP:PORT"
      # -name: dast_server_https_proxy
      #  value: "https://PROXY_IP:PORT"  
    ```

    **Method 2: External Kubernetes Secret:**
    ```yaml
    useSaasKeyAsExternalSecret: true
    externalSecret:
      name: "dast-client-secrets"  # Name of your existing Kubernetes secret
      key: "saas-api-key"  # Key within the secret

    env:
      - name: dast_client_tag
        value: "AppSentinels-created-org-name_dast_client"
      - name: saas_url
        value: "your-saas-server.appsentinels.ai"
      - name: HTTPS_INSECURE_SKIP_VERIFY
        value: "true"  # Set to true if using self-signed certificates
      #- name: aut_auth_https_proxy
      #  valuwe ""https://PROXY_IP:PORT"
      # -name: aut_https_proxy
      #  value: "https://PROXY_IP:PORT"
      # -name: dast_server_https_proxy
      #  value: "https://PROXY_IP:PORT"
    ```

    **Set replicaCount to 1 for standalone client:**
    ```yaml
    replicaCount: 1
    ```

3. Set certificates.enabled to true if client is listening on HTTPS.

4. Deploy the Helm chart:
    ```sh
    helm install appsentinels-dast-client . -n appsentinels
    ```


#### Steps

1. Navigate to the directory containing the Helm chart:

2. Review and update the `values.yaml` file to configure the deployment according to your requirements.

    **Configure the API Key (Required if key isnt a secret):**
    ```yaml
    secrets:
      enabled: true
      saasApiKey: "your-appsentinels-api-key-here"
    ```

    **Configure Environment Variables:**
    ```yaml
    env:
      - name: dast_client_tag
        value: "AppSentinels-created-org-name_dast_client"
      - name: server_url
        value: "your-saas-server.appsentinels.ai"
      - name: api_key
        value:  "......"  # If not using secrets
      - name: HTTPS_INSECURE_SKIP_VERIFY
        value: "true"  # Set to true if using self-signed certificates on SAAS
      #- name: aut_auth_https_proxy
      #  valuwe ""https://PROXY_IP:PORT"
      # -name: aut_https_proxy
      #  value: "https://PROXY_IP:PORT"
      # -name: dast_server_https_proxy
      #  value: "https://PROXY_IP:PORT"
    ```

    **Set replicaCount for scalable deployment:**
    ```yaml
    replicaCount: 3  # Set to desired number of replicas
    ```



### Verifying the Deployment

1. Check the status of the deployment:
    ```sh
    helm status appsentinels-dast-client -n appsentinels
    ```

2. Verify that the pods are running:
    ```sh
    kubectl get pods -n appsentinels
    ```

3. Verify the API key configuration:
    
    **For environment variable mode:**
    ```sh
    kubectl exec -n appsentinels deployment/appsentinels-dast-client -- env | grep SAAS_API_KEY_VALUE
    ```
    
    **For secret mode:**
    ```sh
    # Check that the secret was created
    kubectl get secrets -n appsentinels | grep dast-client
    
    # Verify the API key is loaded from the secret
    kubectl exec -n appsentinels deployment/appsentinels-dast-client -- env | grep SAAS_API_KEY_VALUE
    ```

4. If you have enabled the ingress controller, verify that the ingress resources are created:
    ```sh
    kubectl get ingress -n appsentinels
    ```

5. Check the controller logs:
    ```sh
    kubectl logs -n appsentinels deployment/appsentinels-dast-client
    ```

### Uninstalling the AppSentinels DAST Client

To uninstall the AppSentinels DAST Client, run the following command:

```sh
helm uninstall appsentinels-dast-client -n appsentinels
```
