########################################
# EFS (Elastic File System)
########################################

resource "aws_efs_file_system" "efs" {
  creation_token   = var.filestore_name
  performance_mode = "generalPurpose"
  throughput_mode  = "bursting"

  tags = {
    Name = var.filestore_name
    App  = var.tag
  }
}

resource "aws_efs_mount_target" "mount" {
  for_each = {
    for idx, subnet_id in module.vpc.private_subnets :
    idx => subnet_id
  }

  file_system_id  = aws_efs_file_system.efs.id
  subnet_id       = each.value
  security_groups = [module.eks.cluster_security_group_id]

  depends_on = [module.vpc]
}
