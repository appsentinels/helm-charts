variable "aws_region" {
  default = "eu-north-1"
}

variable "cluster_name" {
  default = "AppSentinels-Cluster"
}

variable "node_group_name" {
  default = "AppSentinels-NodeGroup"
}

variable "filestore_name" {
  default = "AppSentinels-FileStore"
}

variable "tag" {
  default = "AppSentinels"
}

variable "node_instance_type" {
  default = "m5.2xlarge"
}

variable "desired_capacity" {
  default = 2
}

variable "min_capacity" {
  default = 1
}

variable "max_capacity" {
  default = 4
}
