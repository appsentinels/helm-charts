
# EKS Cluster Setup

This guide explains how to create an Amazon EKS cluster using the AWS Console, connect using `eksctl`, set up Amazon EFS with the EFS CSI Driver, and configure Kong Ingress with a static Elastic IP.

---

## Prerequisites

* AWS Account with IAM permissions for EKS, EC2, and EFS
* AWS CLI installed and configured (`aws configure`)

---

## Install Required Tools

### 1. Install AWS CLI

```bash
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install
aws --version
```

Configure it:

```bash
aws configure
```

---

## Steps to Create AWS Access Key & Secret in AWS Console

1. Sign in to [AWS Console](https://aws.amazon.com/console/) → open **IAM**.

2. Go to **Users → your-user → Security credentials**.

3. Under **Access keys**, click **Create access key** → select **CLI** usage.

4. Copy or download the **Access key ID** and **Secret access key**.

5. Configure locally:

   ```bash
   aws configure
   ```

   Example:

   ```
   AWS Access Key ID [None]: AKIAxxxxxxxxxxxx
   AWS Secret Access Key [None]: AbCdEfGhIjKlMnOpQrStUvWxYz1234567890
   Default region name [None]: eu-north-1
   Default output format [None]: json
   ```

6. Verify:

   ```bash
   aws sts get-caller-identity
   ```

---

### 2. Install `eksctl`

```bash
curl -sLO "https://github.com/eksctl-io/eksctl/releases/latest/download/eksctl_$(uname -s)_amd64.tar.gz"
tar -xzf eksctl_$(uname -s)_amd64.tar.gz -C /usr/local/bin
eksctl version
```

---

### 3. Install `kubectl`

```bash
curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"
chmod +x kubectl && sudo mv kubectl /usr/local/bin/
kubectl version --client
```

---

### 4. Install `helm`

```bash
curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash
helm version
```

---

### Verify Setup

```bash
aws --version
eksctl version
kubectl version --client
helm version
```

---

## Create EKS Cluster in AWS Console

1. Go to **AWS Console → EKS → Create cluster**
2. Choose:

   * **Cluster name:** `my-eks-cluster`
   * **Kubernetes version:** latest stable
   * **Cluster service role:** `AmazonEKSClusterRole`
3. Under **Networking**:

   * Create a new **VPC** or use an existing one
   * Ensure subnets are in multiple Availability Zones
   * Enable Public & Private access
4. Click **Create Cluster** — this will take a few minutes.

---

## Connect to Cluster using `eksctl`

After the cluster becomes **Active**:

```bash
aws eks update-kubeconfig --name my-eks-cluster --region eu-north-1
kubectl get svc
```

---

## Create Node Group (Worker Nodes)

After the cluster is active, add at least one Node Group.

### Option 1 — AWS Console

1. Go to **EKS → your cluster → Compute → Add Node Group**
2. Fill in:

   * **Name:** `my-node-group`
   * **IAM Role:** must include
     `AmazonEKSWorkerNodePolicy`, `AmazonEC2ContainerRegistryReadOnly`, `AmazonEKS_CNI_Policy`
   * **Instance type:** `t3.medium` or `t3.large`
   * **Desired:** 2  | **Min:** 1 | **Max:** 4
   * **Subnets:** select those used by your cluster (multi-AZ by default)
3. Enable **SSH access** if needed.
4. Click **Create**.

### Option 2 — Using `eksctl`

```bash
eksctl create nodegroup \
  --cluster my-eks-cluster \
  --name my-node-group \
  --region eu-north-1 \
  --node-type t3.medium \
  --nodes 2 \
  --nodes-min 1 \
  --nodes-max 4 \
  --managed
```

Verify nodes:

```bash
kubectl get nodes
```

Note: By default, AWS uses multiple subnets/AZs for node groups. Each subnet will later require one Elastic IP for your Kong LoadBalancer.

---

## Create Amazon EFS (Elastic File System)

1. Go to **AWS Console → EFS → Create file system**
2. Choose:

   * **Name:** `my-eks-efs`
   * **VPC:** same as EKS cluster
3. Ensure the **EFS security group** allows **NFS (port 2049)**
4. Once created, note the **File System ID** (e.g. `fs-0abcd1234efgh5678`) — this will replace **NFS_SERVER_IP** in your `variables.sh`.

Alternatively via CLI:

```bash
aws efs create-file-system \
  --region eu-north-1 \
  --performance-mode generalPurpose \
  --throughput-mode bursting \
  --tags Key=Name,Value=my-eks-efs
```

---

## Install EFS CSI Driver via Helm

```bash
helm repo add aws-efs-csi-driver https://kubernetes-sigs.github.io/aws-efs-csi-driver/
helm repo update
helm install aws-efs-csi-driver aws-efs-csi-driver/aws-efs-csi-driver \
  --namespace kube-system \
  --set image.repository=602401143452.dkr.ecr.eu-north-1.amazonaws.com/eks/aws-efs-csi-driver
kubectl get pods -n kube-system | grep efs
```

---

## Authorize EKS Security Group to Access EFS

Get your cluster Security Group ID:

```bash
aws eks describe-cluster --name my-eks-cluster --region eu-north-1 \
  --query "cluster.resourcesVpcConfig.clusterSecurityGroupId" --output text
```

Authorize access:

```bash
aws ec2 authorize-security-group-ingress \
  --group-id <EFS-SG-ID> \
  --protocol tcp \
  --port 2049 \
  --source-group <EKS-SG-ID> \
  --region eu-north-1
```

---

## Allocate Static Elastic IPs for Kong LoadBalancer

By default, EKS node groups span multiple subnets (AZs).
Each subnet requires one Elastic IP for the Network Load Balancer (NLB).

### Allocate EIPs

For each subnet (usually 1–3):

```bash
aws ec2 allocate-address --region eu-north-1
```

Example output:

```json
{
  "AllocationId": "eipalloc-0123abcd4567efgh8",
  "PublicIp": "13.50.12.34"
}
```

If using a single subnet, you will get one AllocationId (e.g. eipalloc-0123abcd4567efgh8).
If using multiple subnets (multi-AZ), allocate one Elastic IP per subnet, and store all AllocationIds as a comma-separated list.

Example (multi-AZ):
```bash
export LOADBALANCER_IP="eipalloc-aaa111,eipalloc-bbb222,eipalloc-ccc333"
```

---

## Sample variables.sh

```bash
#!/bin/bash
export HOSTNAME="appsentinels-poc-aks.appsentinels.ai"
export LOADBALANCER_IP="eipalloc-0123abcd4567efgh8"
export POSTGRES_HOST="db"
export NFS_SERVER_IP="fs-0b22e8806cb8bcc1a"
export NFS_PATH="/data"

# Cloud config
export CLOUD_PROVIDER="aws"
export USE_INTERNAL_IP="true"
export LOCAL_DB_SERVICE_ENABLED="true"

# Image repository
export IMAGE_REGISTRY="docker.io/appsentinels"
export IMAGE_REPO_USERNAME="appsentinels"
export IMAGE_REPO_SERVER="https://index.docker.io/v1/"
```

---
