# PostgreSQL Connection Limits

## Problem
```
FATAL: remaining connection slots are reserved for roles with privileges of the "pg_use_reserved_connections" role
```

This error means all available connection slots are exhausted. PostgreSQL reserves a few connections (`reserved_connections`, default 5) for superuser/privileged roles, and the rest (`max_connections - reserved_connections`) are available for regular users.

## Diagnosing

### Check current connection settings
```sql
SHOW max_connections;
SHOW reserved_connections;
SHOW superuser_reserved_connections;
```

### Check active connections
```sql
SELECT count(*) FROM pg_stat_activity;
```

### Check connections by database/user
```sql
SELECT datname, usename, count(*)
FROM pg_stat_activity
GROUP BY datname, usename
ORDER BY count DESC;
```

### Check connection states
```sql
SELECT state, count(*)
FROM pg_stat_activity
GROUP BY state;
```

## Solutions

### 1. Increase max_connections
Edit `postgresql.conf` or set via your managed DB provider's parameter settings:
```
max_connections = 256
```
Requires a server restart.

### 2. Use Connection Pooling (Recommended)
Connection pooling is the best long-term solution. It multiplexes many application connections over fewer database connections.

**PgBouncer** is the most common pooler:
- Many managed PostgreSQL providers offer built-in PgBouncer support
- Can also be deployed as a sidecar or standalone service
- Supports transaction-level pooling (most efficient) and session-level pooling

### 3. Reduce Application Connection Usage
- Lower connection pool sizes in application services
- Ensure connections are properly closed after use
- Use connection timeouts to reclaim idle connections

### 4. Kill Idle Connections
Set `idle_in_transaction_session_timeout` to automatically close idle transactions:
```sql
ALTER SYSTEM SET idle_in_transaction_session_timeout = '5min';
SELECT pg_reload_conf();
```

### 5. Scale Up the Database
Larger instance tiers typically support higher `max_connections` limits. Check your provider's documentation for per-tier limits.

## Managed Database Considerations
- Some parameters (e.g., `reserved_connections`) may be read-only on managed services
- Check provider-specific documentation for max_connections limits per SKU/tier
- Prefer enabling provider's built-in connection pooler if available
