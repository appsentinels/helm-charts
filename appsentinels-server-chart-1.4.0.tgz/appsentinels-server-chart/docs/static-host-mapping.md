# Static Host Mapping in Kubernetes (AKS CoreDNS)

Add static DNS entries inside a Kubernetes cluster using CoreDNS custom configuration.

## When to Use
- Domain DNS is managed externally and you need internal cluster resolution
- Testing with a hostname before public DNS is configured
- Overriding external DNS for internal routing

## Steps

### 1. Check existing CoreDNS custom config
```bash
kubectl get configmap coredns-custom -n kube-system -o yaml
```

### 2. Add static host entry
Apply a ConfigMap with a `hosts` plugin block. The file key must end in `.override`:

```bash
kubectl apply -f - <<'EOF'
apiVersion: v1
kind: ConfigMap
metadata:
  name: coredns-custom
  namespace: kube-system
data:
  myapp.override: |
    hosts {
      <IP_ADDRESS> <HOSTNAME>
      fallthrough
    }
EOF
```

**Example:**
```bash
kubectl apply -f - <<'EOF'
apiVersion: v1
kind: ConfigMap
metadata:
  name: coredns-custom
  namespace: kube-system
data:
  appsentinels.override: |
    hosts {
      4.224.66.12 appsentinels-qdb-uat.appsentinels.ai
      fallthrough
    }
EOF
```

### 3. Restart CoreDNS to apply
```bash
kubectl rollout restart deployment coredns -n kube-system
```

### 4. Verify resolution from within the cluster
```bash
kubectl run dns-test --rm -it --restart=Never --image=busybox -- nslookup <HOSTNAME>
```

Expected output:
```
Server:    10.0.0.10
Address:   10.0.0.10:53

Name:      appsentinels-qdb-uat.appsentinels.ai
Address:   4.224.66.12
```

## Notes
- `fallthrough` is important — it allows queries not matching the hosts block to fall through to other DNS resolvers
- Multiple hosts can be added in the same block:
  ```yaml
  hosts {
    4.224.66.12 appsentinels-qdb-uat.appsentinels.ai
    10.0.0.5 internal-service.example.com
    fallthrough
  }
  ```
- The ConfigMap key name (e.g., `appsentinels.override`) must end with `.override` for AKS
- Changes require a CoreDNS restart to take effect
- This only affects DNS resolution **inside** the cluster, not external clients
