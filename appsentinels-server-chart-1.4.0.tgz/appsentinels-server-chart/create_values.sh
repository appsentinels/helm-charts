#!/bin/bash
set -euo pipefail

source ./variables.sh

# Decide secured docker login
SECURED_LOGIN_VALUE=false
if [[ -n "${IMAGE_REPO_USERNAME:-}" ]]; then
  SECURED_LOGIN_VALUE=true
fi
# Build ADMIN_DB sed expressions based on LOCAL_DB_SERVICE_ENABLED
if [[ "$LOCAL_DB_SERVICE_ENABLED" == "false" ]]; then
  ADMIN_DB_SED='s|.*#REPLACE_ADMIN_DB_BLOCK.*|    - name: ADMIN_DB\n      value: asqdbuat|'
  PIISERVER_ENV_SED='s|.*#REPLACE_PIISERVER_ENV_BLOCK.*|  env:\n    - name: ADMIN_DB\n      value: asqdbuat|'
else
  ADMIN_DB_SED='/#REPLACE_ADMIN_DB_BLOCK/d'
  PIISERVER_ENV_SED='s|.*#REPLACE_PIISERVER_ENV_BLOCK.*|  env: []|'
fi

# Generate final values.yaml in ONE pass
sed \
  -e "s|REPLACE_NAMESPACE|$NAMESPACE|g" \
  -e "s|REPLACE_APPSENTINELS_PLATFORM|$HOSTNAME|g" \
  -e "s|REPLACE_LOADBALANCER_IP|$LOADBALANCER_IP|g" \
  -e "s|REPLACE_POSTGRES_HOST|$POSTGRES_HOST|g" \
  -e "s|REPLACE_LOCAL_DB_SERVICE_ENABLED|$LOCAL_DB_SERVICE_ENABLED|g" \
  -e "s|REPLACE_DOCKER_REGISTRY|$IMAGE_REGISTRY|g" \
  -e "s|securedDockerLogin: false|securedDockerLogin: $SECURED_LOGIN_VALUE|g" \
  -e "s|REPLACE_CLOUD_PROVIDER|$CLOUD_PROVIDER|g" \
  -e "s|REPLACE_USE_INTERNAL_IP|$USE_INTERNAL_IP|g" \
  -e "$ADMIN_DB_SED" \
  -e "$PIISERVER_ENV_SED" \
  ./values.yaml.template > ./values.yaml
