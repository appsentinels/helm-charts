source ./variables.sh

kubectl delete namespace "$NAMESPACE"
kubectl delete -f ./storage/azure/pvc.yaml
kubectl delete -f ./storage/azure/data_storage_class.yaml
kubectl delete -f ./storage/azure/db_storage_class.yaml
