# Helm based Server Installation Guide

## Prerequisites

### Certificate Setup
1. Navigate to `./files/certs`
2. Run `create_certificate.sh` to generate:
   - tls.key
   - tls.pem
   - tls.crt
   
Note: This script also creates a cert secret in Kubernetes and also creates the namespace (configured via `NAMESPACE` in `variables.sh`)

### Secret Configuration
1. Navigate to `./files/secrets`
2. Update the following passwords files (make sure there are no spaces or newlines)
   - DEVOPS: Update password and Database IP address
   - POSTGRES_PASSWORD: Use Kong user's password
3. Update IMAGE_REPO_TOKEN with password or token from docker hub setting page

## Installation Steps

### 1. Pre-Installation Configuration
1. Go back to the top level directory. Open `variables.sh` and configure:
   - NAMESPACE - Kubernetes namespace for the deployment (default: `appsentinels`)
   - nfs_server_ip
   - nfs_path
   - hostname
   - loadbalancer_ip
   - postgres_host
   - IMAGE_REGISTRY - Image registry to be set by default docker.io/appsentinelsai
   - IMAGE_REPO_USERNAME - provide the username for secured login
   - IMAGE_REPO_SERVER - Provide the docker hub server url for secured login

2. Run `pre_installation.sh`. This script also creates the namespace configured in `variables.sh`
   - Install dos2unix && and Run following to remove trailing spaces and extra characters `dos2unix pre_installation.sh variables.sh`
### 2. Verify Resources
1. Check namespace creation (created by `create_certificate.sh` or `pre_installation.sh` using the `NAMESPACE` variable from `variables.sh`)

2. Verify PVC status:
```bash
kubectl get pvc -n $NAMESPACE
```
Expected output:

    NAME         STATUS   VOLUME    CAPACITY   ACCESS MODES   STORAGECLASS   VOLUMEATTRIBUTESCLASS   AGE
    data-claim   Bound    data-pv   1Ti        RWX            manual         <unset>                 8m49s

Note: Capacity here is indicative and may not be actual

Note: DB storage (PV/PVC) is only provisioned when `LOCAL_DB_SERVICE_ENABLED="true"` (local database). When using a managed database (e.g., RDS, Cloud SQL, Azure Database for PostgreSQL), only the data storage is created — no `db-claim` PVC will appear.

3. Verify PV status:
```bash
kubectl get pv -n $NAMESPACE
```

4. Verify secrets:
```bash
kubectl get secrets -n $NAMESPACE
```

### 3. Stage 1 Installation
```bash
helm install <release> . --set stage1.enabled=true
```
Verify that pods kong, keycloak and utils are running fine. kong-migration should have run successfully atleast once
```bash
kubectl get pods -n $NAMESPACE
NAME                              READY   STATUS             RESTARTS        AGE
keycloak-local-b977f4678-4xvtz    1/1     Running            0               14m
kong-5977c454cf-5bdnd             1/1     Running            0               14m
kong-migrations-fc957bc8f-sqstf   0/1     Completed          7 (3m17s ago)   14m
utils-697c85575-r2lzs             1/1     Running            0               14m
```
---

### AWS Setup – Managed PostgreSQL (RDS)

When running the setup on AWS using an RDS PostgreSQL instance, the initial databases must be created manually.

#### Step 1: Access the Utils Pod

Log in to the utils pod using the following command:

```bash
kubectl exec -it utils-<container-id> -- bash
```

#### Step 2: Connect to the RDS Database

Inside the utils container, connect to the RDS instance using `psql`:

```bash
psql "host=<rds_endpoint> \
      port=5432 \
      user=appsentinels_admin \
      dbname=appsentinels \
      sslmode=verify-full \
      sslrootcert=/run/secrets/db-ca.crt"
```

Replace `<rds_endpoint>`, `user`, and `dbname` as required. (Default Username, Database & Password are created as part of terraform script)

#### Step 3: Create Required Databases

After successfully connecting, create the following databases:

```bash
CREATE DATABASE kong;
CREATE DATABASE keycloak;
```

#### Step 4: Create Users and Assign Roles

**Create the DevOps user:**

```bash
CREATE USER devops WITH LOGIN PASSWORD 'password';
```

**Grant database creation privileges and associate the required role:**

```bash
ALTER ROLE devops CREATEDB;
GRANT rds_superuser TO devops;
```

#### Step 5: Restart Application Pods

Exit the utils container and delete the **Keycloak** and **Kong** pods so they reconnect to the database using the newly created databases and roles.

#### Step 6: Verify Connectivity

Ensure that all components establish a successful database connection and are running as expected.

---

### 4. Kong Configuration
1. `exec` into utils container
2. Navigate to `/kubernetes-requirements`
3. Run `./kong_config.sh` and exit
4. Verify Kong service LoadBalancer IP:
```bash
kubectl get svc -n $NAMESPACE | grep LoadBalancer
```

### 5. Keycloak Setup
1. Wait for Keycloak to start and complete verification (~2 minutes). Ensure the server hostname is resolvable before the next step
2. Run `python3 keycloak_setup.py`
3. This will generate:
   - keycloak_user_id.txt
   - keycloak_client_secret.txt
   - keycloak.pem

4. Update auth config:
   1. Copy keycloak_client_secret.txt contents to REPLACE_KEYCLOAK_CLIENT_SECRET in files/secrets/AUTH_CONFIG
   2. Come back to the main directory and update the auth-config-secret
   ```bash 
   kubectl delete secret -n $NAMESPACE auth-config-secret
   kubectl create secret generic auth-config-secret --from-file=auth_config=./files/secrets/AUTH_CONFIG -n $NAMESPACE
   ```

6. Configure Kong JWT:
   - Copy keycloak.pem to utils `/kubernetes-requirements/`
   ```bash
   kubectl cp keycloak.pem -n $NAMESPACE     <utils-pod-name>:/kubernetes-requirements/
   ```
   - Exec to utils, navigate to `/kubernetes-requirements/` and run `kong_jwt.sh`

### 6. Final Configuration
1. Perform directory setup for shared mounts
2. Run:
   ```bash
   ./directory_permission.sh
   ```
3. Exit the utils pod

### 7. Restart Cluster
1. Bring down the cluster for a clean start:
```bash
helm uninstall <release>
```

2. Bring up the cluster with both stages:
```bash
helm install <release> . --set stage2.enabled=true
```

### 8. Create uses and demo organization
1. Exec into utils and navigate to `/kubernetes-requirements`
2. Run below for creating a demo org and an associated org admin `demo@appsentinels.ai`:
   ```bash
      ./default_user_org.sh 
   ```
3. Note down the API key for a demo controller

### 9. Restart the adminapp pod
1. kubectl delete pod <adminapp pod name> -n $NAMESPACE

## DB Migration Process
1. Run `helm upgrade <release> . --set db_migration.enabled=true`
2. Copy migration script into utils pod and run it from there

## Kafka Maintenance
1. Run `helm upgrade <release> . --set kafka_care.enabled=true`
2. Perform any maintenance tasks as needed from kafka pod

--- 

### TODO
- ~~Namespace is not configurable~~ (Done: namespace is now configurable via `NAMESPACE` in `variables.sh`)
