## Deploying the AppSentinels Edge Controller using Helm

### Prerequisites
- Ensure you have Helm installed on your system.
- Ensure you have access to the Kubernetes cluster where you want to deploy the AppSentinels Edge Controller.
- Ensure you have `kubectl` configured to access your cluster.

### Security Configuration

The Helm chart supports two methods for handling the `SAAS_API_KEY_VALUE`:

#### Method 1: Direct Environment Variable (Default)
- **SAAS_API_KEY_VALUE** is defined directly in the `env` array in `values.yaml`
- This is the existing implementation - no changes needed for current users
- Simple and straightforward for development and testing environments

#### Method 2: External Kubernetes Secret (Recommended for Production)
- Uses an existing Kubernetes secret created with `kubectl create secret generic`
- Only requires specifying the secret `name` and `key`
- More secure for production environments
- Integrates with external secret management systems

**Important:** Never commit your actual API key to version control. Use environment variables or secure secret management tools in production.

### Configuration Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `useSaasKeyAsExternalSecret` | boolean | `false` | Set to `true` to use external Kubernetes secret |
| `externalSecret.name` | string | `"edge-controller-secrets"` | Name of the existing Kubernetes secret |
| `externalSecret.key` | string | `"saas-api-key"` | Key within the secret that contains the SAAS_API_KEY_VALUE |

### Configuration Methods

#### Method 1: Direct Environment Variable (Default)

This method defines `SAAS_API_KEY_VALUE` directly in the `env` array in `values.yaml`. This is the existing implementation and requires no changes for current users.

**Configuration:**
```yaml
useSaasKeyAsExternalSecret: false  # Default value

env:
  - name: APPLICATION_DOMAIN
    value: "your-application-domain"
  - name: ENVIRONMENT
    value: "production"
  - name: SAAS_SERVER_NAME
    value: "your-saas-server.appsentinels.ai"
  - name: SAAS_API_KEY_VALUE
    value: "your-appsentinels-api-key-here"
  - name: HTTPS_INSECURE_SKIP_VERIFY
    value: "true"
```

**Deployment:**
```bash
helm install edge-controller . -n appsentinels
```

#### Method 2: External Kubernetes Secret (Recommended for Production)

This method uses an existing Kubernetes secret created with `kubectl create secret generic`. The chart only references the secret by name and key.

**Step 1: Create the Kubernetes Secret**
```bash
kubectl create secret generic edge-controller-secrets \
  --from-literal=saas-api-key="your-appsentinels-api-key-here" \
  -n appsentinels
```

**Step 2: Configure the Chart**
```yaml
useSaasKeyAsExternalSecret: true
externalSecret:
  name: "edge-controller-secrets"  # Name of the existing Kubernetes secret
  key: "saas-api-key"  # Key within the secret

# ⚠️ Do **not** define `SAAS_API_KEY_VALUE` in the `env` section below when `useSaasKeyAsExternalSecret: true`. The value will be sourced from the referenced Kubernetes secret.

env:
  - name: APPLICATION_DOMAIN
    value: "your-application-domain"
  - name: ENVIRONMENT
    value: "production"
  - name: SAAS_SERVER_NAME
    value: "your-saas-server.appsentinels.ai"
  - name: HTTPS_INSECURE_SKIP_VERIFY
    value: "true"
```

**Step 3: Deploy**
```bash
helm install edge-controller . -n appsentinels
```

### Deployment as Standalone Controller

> Service (9004) --> Deployment (port 9004)

#### Initial Setup

1. Create the `appsentinels` namespace:
    ```sh
    kubectl create namespace appsentinels
    ```

2. If the controller is listening on TLS, create the necessary certificates or secrets.
    ```sh
    kubectl create secret generic appsentinels-certs \
      --from-file=server.crt=/path/to/your/server.crt \
      --from-file=server.key=/path/to/your/server.key \
      -n appsentinels
    ```

#### Steps

1. Navigate to the directory containing the Helm chart:

2. Review and update the `values.yaml` file to configure the deployment according to your requirements.

    **Method 1: Direct Environment Variable (Default):**
    ```yaml
    useExternalSecret: false

    env:
      - name: APPLICATION_DOMAIN
        value: "your-application-domain"
      - name: ENVIRONMENT
        value: "production"  # or dev, qa, staging
      - name: SAAS_SERVER_NAME
        value: "your-saas-server.appsentinels.ai"
      - name: SAAS_API_KEY_VALUE
        value: "your-appsentinels-api-key-here"
      - name: HTTPS_INSECURE_SKIP_VERIFY
        value: "true"  # Set to true if using self-signed certificates
    ```

    **Method 2: External Kubernetes Secret:**
    ```yaml
    useSaasKeyAsExternalSecret: true
    externalSecret:
      name: "edge-controller-secrets"  # Name of your existing Kubernetes secret
      key: "saas-api-key"  # Key within the secret

    env:
      - name: APPLICATION_DOMAIN
        value: "your-application-domain"
      - name: ENVIRONMENT
        value: "production"  # or dev, qa, staging
      - name: SAAS_SERVER_NAME
        value: "your-saas-server.appsentinels.ai"
      - name: HTTPS_INSECURE_SKIP_VERIFY
        value: "true"  # Set to true if using self-signed certificates
    ```

    **Set replicaCount to 1 for standalone controller:**
    ```yaml
    replicaCount: 1
    ```

3. Set certificates.enabled to true if controller is listening on HTTPS.

4. Deploy the Helm chart:
    ```sh
    helm install appsentinels-edge-controller . -n appsentinels
    ```

### Deployment as a Scalable Controller (using Ingress Controller)

> Ingress (TLS) (443/80)--> Service (HTTP) (9004) --> Deployment (port 9004)


#### Initial Setup

1. Create the `appsentinels` namespace:
    ```sh
    kubectl create namespace appsentinels
    ```

2. If ingress is to listen on HTTPS (port 443) create the ingress TLS secret for ingress controller to listen on HTTPS.
    ```sh
    kubectl create secret tls edge-controller-ingress-tls --cert=path/to/tls.crt --key=path/to/tls.key -n appsentinels
    ```
    and enable the ingress.tls block in values.yaml

    If ingress is to listen on HTTP (port 80) then disable the ingress.tls block in values.yaml

3. Enable ingress controller in your cluster if not already enabled. 

    For nginx provided K8 ingress controller follow the below instructions,
    ```sh
    helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx
    helm repo update

    helm install ingress-nginx ingress-nginx/ingress-nginx \
        --namespace ingress-nginx --create-namespace \
        --set controller.replicaCount=2 \
        --set controller.nodeSelector."kubernetes\.io/os"=linux \
        --set controller.service.externalTrafficPolicy=Local \
        --set controller.service.annotations."service\.beta\.kubernetes\.io/azure-load-balancer-internal"="false"  #For Azure Ingress LB only
    ```

    For Azure, please append the below annotations for external internet-facing ingress controller,
    ```sh
        service.beta.kubernetes.io/azure-load-balancer-internal: "false"
        service.beta.kubernetes.io/azure-load-balancer-sku: "Standard"
        service.beta.kubernetes.io/azure-load-balancer-health-probe-request-path: "/healthz"
    ```

#### Steps

1. Navigate to the directory containing the Helm chart:

2. Review and update the `values.yaml` file to configure the deployment according to your requirements.

    **Configure the API Key (Required if key isnt a secret):**
    ```yaml
    secrets:
      enabled: true
      saasApiKey: "your-appsentinels-api-key-here"
    ```

    **Configure Environment Variables:**
    ```yaml
    env:
      - name: APPLICATION_DOMAIN
        value: "your-application-domain"
      - name: ENVIRONMENT
        value: "production"  # or dev, qa, staging
      - name: SAAS_SERVER_NAME
        value: "your-saas-server.appsentinels.ai"
      - name: SAAS_API_KEY_VALUE
        value:  "......"  # If not using secrets
      - name: HTTPS_INSECURE_SKIP_VERIFY
        value: "true"  # Set to true if using self-signed certificates on SAAS
    ```

    **Set replicaCount for scalable deployment:**
    ```yaml
    replicaCount: 3  # Set to desired number of replicas
    ```

    **Note:** There is no need to enable TLS for edge controller as ingress controller will handle it.

3. Review and update the `values.yaml` file to configure the deployment according to your requirements. In addition to the parameters mentioned above, ensure the following parameters are set for the ingress controller:
    - `ingress.enabled`: Set to `true` to enable the ingress controller.
    - `ingress.hosts`: Set the hosts for the ingress, this should match the host in the ingress TLS secret.
    - `ingress.tls`: Configure TLS settings for the ingress controller.

4. Deploy the Helm chart with ingress enabled:
    ```sh
    helm install appsentinels-edge-controller . -n appsentinels
    ```

### Verifying the Deployment

1. Check the status of the deployment:
    ```sh
    helm status appsentinels-edge-controller -n appsentinels
    ```

2. Verify that the pods are running:
    ```sh
    kubectl get pods -n appsentinels
    ```

3. Verify the API key configuration:
    
    **For environment variable mode:**
    ```sh
    kubectl exec -n appsentinels deployment/appsentinels-edge-controller -- env | grep SAAS_API_KEY_VALUE
    ```
    
    **For secret mode:**
    ```sh
    # Check that the secret was created
    kubectl get secrets -n appsentinels | grep edge-controller
    
    # Verify the API key is loaded from the secret
    kubectl exec -n appsentinels deployment/appsentinels-edge-controller -- env | grep SAAS_API_KEY_VALUE
    ```

4. If you have enabled the ingress controller, verify that the ingress resources are created:
    ```sh
    kubectl get ingress -n appsentinels
    ```

5. Check the controller logs:
    ```sh
    kubectl logs -n appsentinels deployment/appsentinels-edge-controller
    ```

### Uninstalling the AppSentinels Edge Controller

To uninstall the AppSentinels Edge Controller, run the following command:

```sh
helm uninstall appsentinels-edge-controller -n appsentinels
```