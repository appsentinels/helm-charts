import yaml
from typing import Dict, Tuple

def parse_resource_value(value: str) -> float:
    """Convert CPU/memory values to numeric format."""
    if isinstance(value, (int, float)):
        return float(value)
    
    # Handle CPU values
    if value.endswith('m'):
        return float(value[:-1]) / 1000
    
    # Handle memory values
    if value.endswith('Gi'):
        return float(value[:-2]) * 1024
    if value.endswith('Mi'):
        return float(value[:-2])
    
    return float(value)

def analyze_resources(yaml_file: str) -> None:
    """Analyze resource usage from values.yaml template."""
    with open(yaml_file, 'r') as f:
        data = yaml.safe_load(f)
    
    total_cpu_limits = 0
    total_cpu_requests = 0
    total_memory_limits = 0
    total_memory_requests = 0
    total_max_cpu = 0
    total_max_memory = 0
    
    print("Resource Usage Per Service:")
    print("-" * 140)
    print(f"{'Service':<25} {'CPU Limits':>10} {'CPU Requests':>12} {'Mem Limits (GB)':>15} {'Mem Requests (GB)':>18} {'Max CPU':>12} {'Max Mem (GB)':>15} {'Autoscaling':>15}")
    print("-" * 140)
    
    for service_name, service_data in data.items():
        if isinstance(service_data, dict) and 'resources' in service_data:
            resources = service_data['resources']
            autoscaling_info = ""
            replicas = 1
            
            if 'autoscaling' in service_data and service_data['autoscaling'].get('enabled', False):
                min_replicas = service_data['autoscaling'].get('minReplicas', 1)
                max_replicas = service_data['autoscaling'].get('maxReplicas', 1)
                replicas = min_replicas  # Use min replicas for base calculations
                autoscaling_info = f"{min_replicas}-{max_replicas}"
            else:
                replicas = service_data.get('replicas', 1)
                max_replicas = replicas
                autoscaling_info = str(replicas)
            
            if 'limits' in resources and 'requests' in resources:
                cpu_limit = parse_resource_value(resources['limits'].get('cpu', '0'))
                cpu_request = parse_resource_value(resources['requests'].get('cpu', '0'))
                mem_limit = parse_resource_value(resources['limits'].get('memory', '0')) / 1024
                mem_request = parse_resource_value(resources['requests'].get('memory', '0')) / 1024
                
                # Multiply base values by replicas
                cpu_limit *= replicas
                cpu_request *= replicas
                mem_limit *= replicas
                mem_request *= replicas
                
                max_cpu = cpu_limit * (max_replicas / replicas)  # Adjust for max replicas
                max_mem = mem_limit * (max_replicas / replicas)  # Adjust for max replicas
                
                total_cpu_limits += cpu_limit
                total_cpu_requests += cpu_request
                total_memory_limits += mem_limit
                total_memory_requests += mem_request
                total_max_cpu += max_cpu
                total_max_memory += max_mem
                
                print(f"{service_name:<25} {cpu_limit:>10.2f} {cpu_request:>12.2f} {mem_limit:>15.2f} {mem_request:>18.2f} {max_cpu:>12.2f} {max_mem:>15.2f} {autoscaling_info:>15}")
    
    print("-" * 140)
    print(f"{'TOTAL':<25} {total_cpu_limits:>10.2f} {total_cpu_requests:>12.2f} {total_memory_limits:>15.2f} {total_memory_requests:>18.2f} {total_max_cpu:>12.2f} {total_max_memory:>15.2f}")
    print("\nNotes:")
    print("- CPU values are in cores")
    print("- Memory values are in GiB")
    print("- Max CPU and Max Mem columns show total resources when scaled to maximum replicas")

if __name__ == "__main__":
    analyze_resources("values.yaml.template")
