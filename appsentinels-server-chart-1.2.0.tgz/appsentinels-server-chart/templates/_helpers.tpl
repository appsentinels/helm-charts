{{/*
Expand the name of the chart.
*/}}
{{- define "helm-server-chart.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "helm-server-chart.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Generate environment variables with optional SSL configuration.
Merges service env vars with SSL env vars if sslmode is not "disable".
PGSSLMODE is always set to db_setup.sslmode value when it's not "disable".
Usage: {{ include "helm-server-chart.envWithSSL" (dict "serviceEnv" .Values.serviceName.env "Values" .Values "indent" 12) }}
*/}}
{{- define "helm-server-chart.envWithSSL" -}}
{{- $serviceEnv := .serviceEnv | default list }}
{{- $env := $serviceEnv }}
{{- if and .Values.db_setup .Values.db_setup.sslmode (ne .Values.db_setup.sslmode "disable") }}
{{- $sslmode := .Values.db_setup.sslmode }}
{{- $sslEnv := list (dict "name" "PGSSLMODE" "value" $sslmode) }}
{{- if .Values.db_setup.dbCaCertSecret }}
{{- $sslEnv = append $sslEnv (dict "name" "PGSSLROOTCERT" "value" "/run/secrets/db-ca.crt") }}
{{- end }}
{{- $env = concat $serviceEnv $sslEnv }}
{{- end }}
{{- $env | toYaml | nindent .indent }}
{{- end }}

{{/*
Generate Kong SSL environment variables based on db_setup.sslmode.
KONG_LUA_SSL_TRUSTED_CERTIFICATE is always set unconditionally.
KONG_PG_SSL and KONG_PG_SSL_VERIFY are set based on sslmode:
  - verify-full: KONG_PG_SSL=on, KONG_PG_SSL_VERIFY=on
  - verify-ca: KONG_PG_SSL=on, KONG_PG_SSL_VERIFY=on
  - require: KONG_PG_SSL=on, KONG_PG_SSL_VERIFY=off
  - disable: KONG_PG_SSL=off, KONG_PG_SSL_VERIFY=off
Usage: {{ include "helm-server-chart.kongSSLEnv" (dict "Values" .Values "indent" 12) }}
*/}}
{{- define "helm-server-chart.kongSSLEnv" -}}
{{- $sslmode := "disable" }}
{{- if and .Values.db_setup .Values.db_setup.sslmode }}
{{- $sslmode = .Values.db_setup.sslmode }}
{{- end }}
{{- $kongSSLEnv := list (dict "name" "KONG_LUA_SSL_TRUSTED_CERTIFICATE" "value" "/run/secrets/db-ca.crt") }}
{{- if or (eq $sslmode "verify-full") (eq $sslmode "verify-ca") }}
{{- $kongSSLEnv = append $kongSSLEnv (dict "name" "KONG_PG_SSL" "value" "on") }}
{{- $kongSSLEnv = append $kongSSLEnv (dict "name" "KONG_PG_SSL_VERIFY" "value" "on") }}
{{- else if eq $sslmode "require" }}
{{- $kongSSLEnv = append $kongSSLEnv (dict "name" "KONG_PG_SSL" "value" "on") }}
{{- $kongSSLEnv = append $kongSSLEnv (dict "name" "KONG_PG_SSL_VERIFY" "value" "off") }}
{{- else }}
{{- $kongSSLEnv = append $kongSSLEnv (dict "name" "KONG_PG_SSL" "value" "off") }}
{{- $kongSSLEnv = append $kongSSLEnv (dict "name" "KONG_PG_SSL_VERIFY" "value" "off") }}
{{- end }}
{{- $kongSSLEnv | toYaml | nindent .indent }}
{{- end }}

{{/*
Generate Kong environment variables with SSL configuration merged.
Merges kong.env with Kong SSL env vars based on db_setup.sslmode.
Usage: {{ include "helm-server-chart.kongEnvWithSSL" (dict "kongEnv" .Values.kong.env "Values" .Values "indent" 12) }}
*/}}
{{- define "helm-server-chart.kongEnvWithSSL" -}}
{{- $kongEnv := .kongEnv | default list }}
{{- $sslmode := "disable" }}
{{- if and .Values.db_setup .Values.db_setup.sslmode }}
{{- $sslmode = .Values.db_setup.sslmode }}
{{- end }}
{{- $kongSSLEnv := list (dict "name" "KONG_LUA_SSL_TRUSTED_CERTIFICATE" "value" "/run/secrets/db-ca.crt") }}
{{- if or (eq $sslmode "verify-full") (eq $sslmode "verify-ca") }}
{{- $kongSSLEnv = append $kongSSLEnv (dict "name" "KONG_PG_SSL" "value" "on") }}
{{- $kongSSLEnv = append $kongSSLEnv (dict "name" "KONG_PG_SSL_VERIFY" "value" "on") }}
{{- else if eq $sslmode "require" }}
{{- $kongSSLEnv = append $kongSSLEnv (dict "name" "KONG_PG_SSL" "value" "on") }}
{{- $kongSSLEnv = append $kongSSLEnv (dict "name" "KONG_PG_SSL_VERIFY" "value" "off") }}
{{- else }}
{{- $kongSSLEnv = append $kongSSLEnv (dict "name" "KONG_PG_SSL" "value" "off") }}
{{- $kongSSLEnv = append $kongSSLEnv (dict "name" "KONG_PG_SSL_VERIFY" "value" "off") }}
{{- end }}
{{- $env := concat $kongEnv $kongSSLEnv }}
{{- $env | toYaml | nindent .indent }}
{{- end }}

