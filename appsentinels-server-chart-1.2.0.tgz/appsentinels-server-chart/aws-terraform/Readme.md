
# Terraform EKS Infrastructure Setup

This repository contains Terraform code to create an **Amazon EKS cluster**, **EFS storage**, and **Elastic IPs** for use with load balancers such as Kong.

---

## Prerequisites

Before running Terraform:

* An AWS account with permissions for **EKS**, **EC2**, **VPC**, and **EFS**
* [Terraform](https://developer.hashicorp.com/terraform/downloads) ≥ 1.6 installed
* [AWS CLI](https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html) configured

  ```bash
  aws configure
  ```

  Example:

  ```
  AWS Access Key ID [None]: AKIAxxxxxxxxxxxx
  AWS Secret Access Key [None]: AbCdEfGhIjKlMnOpQrStUvWxYz1234567890
  Default region name [None]: eu-north-1
  Default output format [None]: json
  ```

---

## Project Structure

```
terraform/
├── providers.tf      # AWS and Kubernetes providers
├── variables.tf      # Input variables (region, cluster name, etc.)
├── vpc.tf            # VPC and subnets (private + public)
├── eks.tf            # EKS cluster and node group
├── efs.tf            # Amazon EFS setup
├── eip.tf            # Elastic IP allocation for Load Balancer
├── outputs.tf        # Important values printed after apply
└── main.tf           # Optional root orchestrator file
```

---

## Steps to Deploy

### 1. Initialize Terraform

```bash
terraform init -upgrade
```

This downloads all required providers and modules.

---

### 2. Review the Plan

```bash
terraform plan
```

Terraform shows what resources it will create (VPC, EKS, EFS, EIP, etc.).

---

### 3. Apply the Infrastructure

Set the password as an environment variable before running Terraform
```bash
export TF_VAR_db_password="VeryStrongPassword"
terraform apply
```
If TF_VAR_db_password is not set, Terraform will prompt securely: 
```bash
terraform apply
```
Terraform will ask:
```bash
var.db_password
  Enter a value:
```

Confirm with `yes`.
It will take ~10–15 minutes to create all AWS resources.

---

### 4. Configure kubectl for the EKS cluster

After successful creation, connect your local `kubectl` to the new cluster:

```bash
aws eks update-kubeconfig --name my-eks-cluster --region eu-north-1
kubectl get nodes
```

---

### 5. View Outputs

Terraform prints key details after apply, such as:

| Output                    | Description                                |
| ------------------------- | ------------------------------------------ |
| `eks_cluster_endpoint`    | API endpoint for the EKS cluster           |
| `efs_id`                  | EFS File System ID (use as NFS server)     |
| `efs_dns_name`            | DNS address for mounting EFS               |
| `kong_eip_allocation_ids` | Allocation IDs for static Elastic IPs      |
| `kong_eip_public_ips`     | Public IPs reserved for your load balancer |

You can list them anytime:

```bash
terraform output
```

Or export them as JSON:

```bash
terraform output -json > outputs.json
```

---

## Cleanup

To destroy all resources:

```bash
terraform destroy
```

This removes the EKS cluster, EFS, and all related infrastructure.

---

## AWS Cluster Requirements

The following AWS components will be provisioned using **Terraform** and **Helm charts**.

### EKS Cluster

* **Instance Type:** `t3.2xlarge`
  * 8 vCPUs
  * 32 GB memory
* **Node Count:** 4-7 worker nodes

### Storage

* **Amazon EFS:**

  * Used as a shared file system for persistent data storage

### Networking

* **Elastic IP (EIP):**

  * Public and private access to the cluster as required

### Database

* **Amazon RDS – PostgreSQL:**

  * Storage: 250 GB
  * Compute: 4 vCPUs
  * Memory: 32 GB RAM
  * Version: 17.5

---

## Next Steps (Manual)

After Terraform setup:

1. Use `kubectl` to verify cluster connectivity.
2. Manually install your Helm charts (Kong, EFS CSI Driver, etc.).
3. Use EFS ID and EIP Allocation IDs from Terraform outputs inside your Helm values or environment variables.

---
