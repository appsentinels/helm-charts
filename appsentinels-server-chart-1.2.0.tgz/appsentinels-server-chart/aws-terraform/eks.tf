module "eks" {
  source  = "terraform-aws-modules/eks/aws"
  version = "~> 20.0" # latest major version as of 2025

  cluster_name    = var.cluster_name
  cluster_version = "1.34"

  # VPC and subnet info
  vpc_id     = module.vpc.vpc_id
  subnet_ids = module.vpc.private_subnets

  # Enable automatic aws-auth ConfigMap management
  # manage_aws_auth_configmap = true
  create_cloudwatch_log_group = false
  eks_managed_node_groups = {
    default = {
      instance_types = [var.node_instance_type]
      desired_size   = var.desired_capacity
      min_size       = var.min_capacity
      max_size       = var.max_capacity
    }
  }

  tags = {
    Environment = "Prod"
    Project     = "appsentinels-eks-cluster"
  }
}

data "aws_eks_cluster_auth" "main" {
  name = module.eks.cluster_name
}
