resource "aws_db_instance" "postgres" {
  identifier = lower("${var.cluster_name}-postgres")

  engine               = "postgres"
  # engine_version     = var.db_engine_version   # commented for now
  instance_class       = var.db_instance_class
  allocated_storage    = var.db_allocated_storage
  storage_type         = "gp3"
  # TLS enforcement
  parameter_group_name = aws_db_parameter_group.postgres_tls.name
  db_name              = var.db_name
  username             = var.db_username
  password             = var.db_password

  db_subnet_group_name = aws_db_subnet_group.postgres.name
  vpc_security_group_ids = [
    aws_security_group.postgres.id
  ]

  multi_az             = var.db_multi_az
  publicly_accessible  = false
  backup_retention_period = var.db_backup_retention

  deletion_protection  = false
  skip_final_snapshot  = true

  performance_insights_enabled = true

  tags = {
    Name = "${var.tag}-postgres"
    App  = var.tag
  }
}


resource "aws_db_subnet_group" "postgres" {
  name       = lower("${var.cluster_name}-db-subnet-group")
  subnet_ids = module.vpc.private_subnets

  tags = {
    Name = "${var.tag}-db-subnet-group"
  }
}

resource "aws_security_group" "postgres" {
  name        = "${var.cluster_name}-postgres-sg"
  description = "Allow PostgreSQL from EKS"
  vpc_id      = module.vpc.vpc_id

  ingress {
    from_port       = 5432
    to_port         = 5432
    protocol        = "tcp"
    security_groups = [module.eks.cluster_security_group_id]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "${var.tag}-postgres-sg"
  }
}

resource "aws_db_parameter_group" "postgres_tls" {
  name   = lower("${var.cluster_name}-pg15-tls")
  family = "postgres17"

  parameter {
    name  = "rds.force_ssl"
    value = "1"
  }
  parameter {
    name         = "max_connections"
    value        = var.db_max_connections
    apply_method = "pending-reboot"
  }
  # Kill bad clients automatically (idle connections)
  parameter {
    name         = "idle_session_timeout"
    value        = "600000"
    apply_method = "immediate"
  }

  tags = {
    Name = "${var.tag}-pg-tls"
  }
}