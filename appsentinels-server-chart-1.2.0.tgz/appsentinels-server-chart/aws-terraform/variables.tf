variable "aws_region" {
  default = "eu-north-1"
}

variable "cluster_name" {
  default = "AppSentinels-Cluster"
}

variable "node_group_name" {
  default = "AppSentinels-NodeGroup"
}

variable "filestore_name" {
  default = "AppSentinels-FileStore"
}

variable "tag" {
  default = "AppSentinels"
}

variable "node_instance_type" {
  default = "m5.2xlarge"
}

variable "desired_capacity" {
  default = 2
}

variable "min_capacity" {
  default = 1
}

variable "max_capacity" {
  default = 4
}

########################################
# RDS PostgreSQL Variables
########################################

variable "db_name" {
  default = "appsentinels"
}

variable "db_username" {
  default = "appsentinels_admin"
}

variable "db_password" {
  type      = string
  sensitive = true
}

variable "db_instance_class" {
  default = "db.r5.xlarge"
}

variable "db_allocated_storage" {
  default = 250
}

variable "db_engine_version" {
  default = "17.5"
}

variable "db_multi_az" {
  default = false
}

variable "db_backup_retention" {
  default = 7
}

variable "db_max_connections" {
  default = 2000
}
