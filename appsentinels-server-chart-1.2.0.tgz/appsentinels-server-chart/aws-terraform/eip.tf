resource "aws_eip" "kong_eip" {
  count = length(module.vpc.public_subnets)
  domain = "vpc"
  tags = {
    Name = var.tag
  }
}