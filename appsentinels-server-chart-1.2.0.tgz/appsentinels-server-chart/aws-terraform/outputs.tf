########################################
# EKS Cluster Outputs
########################################

output "eks_cluster_name" {
  description = "EKS cluster name"
  value       = module.eks.cluster_name
}

output "eks_cluster_endpoint" {
  description = "EKS API server endpoint"
  value       = module.eks.cluster_endpoint
}

output "eks_cluster_certificate_authority_data" {
  description = "EKS cluster CA data (base64 encoded)"
  value       = module.eks.cluster_certificate_authority_data
}

output "eks_cluster_security_group_id" {
  description = "Cluster security group ID"
  value       = module.eks.cluster_security_group_id
}

########################################
# Node Group Details
########################################

output "eks_node_group_arn" {
  description = "EKS managed node group ARN"
  value       = module.eks.eks_managed_node_groups["default"].node_group_arn
}

########################################
# EFS (File Store) Outputs
########################################

output "efs_id" {
  description = "EFS File System ID"
  value       = aws_efs_file_system.efs.id
}

output "efs_dns_name" {
  description = "EFS DNS name"
  value       = aws_efs_file_system.efs.dns_name
}

output "efs_mount_targets" {
  description = "EFS mount target IDs per subnet"
  value       = [for mt in aws_efs_mount_target.mount : mt.id]
}

########################################
# Elastic IP (EIP) Outputs
########################################

output "kong_eip_public_ips" {
  description = "List of public IPs for Kong LoadBalancer"
  value       = [for eip in aws_eip.kong_eip : eip.public_ip]
}

output "kong_eip_allocation_ids" {
  description = "List of Elastic IP allocation IDs"
  value       = [for eip in aws_eip.kong_eip : eip.id]
}

########################################
# Convenience Outputs
########################################

output "aws_region" {
  description = "AWS region used"
  value       = var.aws_region
}

########################################
# RDS Outputs
########################################

output "rds_endpoint" {
  description = "PostgreSQL endpoint"
  value       = aws_db_instance.postgres.endpoint
}
