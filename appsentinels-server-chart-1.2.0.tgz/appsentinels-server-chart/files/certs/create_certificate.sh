openssl genpkey -algorithm RSA -out tls.key
openssl req -new -key tls.key -out tls.pem
openssl req -x509 -days 365 -key tls.key -in tls.pem -out tls.crt
openssl x509 -in tls.crt -text -noout

sleep 2

echo "==== Creating namespace for appsentinels ===="
kubectl create namespace appsentinels

echo "Creating secret for cluster certificate"
kubectl create secret tls clustercert --cert=./tls.crt --key=./tls.key -n appsentinels
