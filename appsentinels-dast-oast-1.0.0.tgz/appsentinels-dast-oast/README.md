## Deploying the AppSentinels DAST OAST server using Helm

Runs the OAST server in the same Kubernetes cluster as the DAST client, so the DAST client and the application under test reach it over the cluster network.

### Install

```bash
helm repo add appsentinels https://appsentinels.github.io/helm-charts/
helm repo update

kubectl create secret generic oast-config \
  --from-literal=oast_pre_shared_key="<OAST pre-shared key from AppSentinels>" \
  -n appsentinels

helm install dast-oast appsentinels/appsentinels-dast-oast -n appsentinels \
  --set usePreSharedKeyAsExternalSecret=true
```

### Register the server in AppSentinels

Add it as an on-prem OAST server for the org, using the service DNS names:

| Field | Value | Must be reachable from |
|-------|-------|------------------------|
| Admin URL | `https://appsentinels-dast-oast.appsentinels.svc.cluster.local:9010` | DAST client |
| Web URL | `https://appsentinels-dast-oast.appsentinels.svc.cluster.local:9011` | Application under test |

The DAST client registers the org key on the first OAST test using the pre-shared key; use **Check Reachability** to confirm.

### Configuration

| Parameter | Default | Description |
|-----------|---------|-------------|
| `image.repository` / `image.tag` | `appsentinels/dast-oast` / `latest` | Server image |
| `preSharedKey` | `""` | Pre-shared key set directly (stored in a chart-managed secret) |
| `usePreSharedKeyAsExternalSecret` | `false` | Read the pre-shared key from `externalSecret.name` / `externalSecret.key` |
| `tls.existingSecret` | `""` | `kubernetes.io/tls` secret for the server cert; empty = self-signed |
| `persistence.enabled` | `true` | Volume for registered org keys and the generated cert |
| `persistence.existingClaim` | `""` | Use an existing PVC |
| `persistence.storageClass` / `size` | `""` / `100Mi` | PVC settings |
| `env` | see `values.yaml` | `AUTH_MODE`, `HSTS`, `OAST_LOG_LEVEL`, etc. |
| `service.type` | `ClusterIP` | Service type |
| `service.adminPort` / `publicPort` | `9010` / `9011` | Service ports |
| `resources` | 0.99 CPU / 1024Mi | Container limits |

### Notes

- **Keep persistence enabled.** Registered org keys live on the volume; if they are lost on a restart, OAST tests fail with `oast_auth_failure` until the server is re-saved in AppSentinels. The PVC is kept on `helm uninstall`.
- **Single replica only.** Callback events are held in memory, so the chart always runs one pod.
- **Self-signed cert.** Applications that verify TLS certificates cannot complete callbacks to a self-signed server; set `tls.existingSecret` with a cert they trust.
