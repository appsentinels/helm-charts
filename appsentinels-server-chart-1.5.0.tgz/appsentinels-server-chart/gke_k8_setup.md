# Google Cloud Platform (GCP) Setup Guide

## 1. Creating GKE Cluster
1. Navigate to GCP Console > Kubernetes Engine > Clusters
2. Click "Create Cluster"
3. Configure cluster settings:
   - Mode: Standard (Note: Autopilot evaluation pending)
   - Name: e.g., `appsentinels-poc-1-helm-cluster`
   - Location type: Zonal (e.g., us-central1-c)
   - Node Pool Configuration:
     - Name: e.g., `poc-pool-1`
     - Number of nodes: 5-6
     - Machine type: 8 CPU, 32GB RAM
     - Boot disk size: 100GB
4. Click Create and wait ~5 minutes
5. Go to VM instances and note the IP addresses of all created nodes

## 2. Reserving Static IP
1. Navigate to VPC Networks > IP addresses
2. Click "Reserve static address"
3. Configure:
   - Name: e.g., `appsentinels-poc-1-helm-ip`
   - Tier: Premium (required for load balancer)
   - Type: Regional
4. Note the allocated IP address
5. Map the IP to your domain

## 3. Creating Shared Storage (Filestore)
1. Navigate to Filestore
2. Create new instance:
   - Instance ID: e.g., `appsentinels-poc-1-helm-cluster-disk`
   - Type: Zonal (match cluster zone)
   - Capacity: 1-9.75 TB
   - Network: default (or as needed)
   - File share name: e.g., `poc_1_data`
3. Wait for provisioning
4. Note the IP address and NFS mount point

## 4. Setting up PostgreSQL
1. Navigate to SQL
2. Create new instance:
   - Database: PostgreSQL
   - Edition: Enterprise
   - Preset: Production/Development
   - Version: 16
   - Instance ID: e.g., `appsentinels-poc-1-db`
3. Configure:
   - Region: Match cluster region
   - Zone: Single zone (match cluster)
   - Data Protection: Disable unused features
   - Backups: Disable if not needed
   - Navigate to the Connection settings and enable Private IP. Disable Public IP, which is selected by default.
   - Enable Private Service Access (PSA) and choose the Default Network for PSA. If required create Private Service Access Network.
4. Configure secure connections:
   - Go to Connections > Security > Manage SSL Mode
   - Set SSL Mode to "Allow only SSL connections"
5. Database Setup:
   - Create users:
     - asadmin
     - kong
     - Note: Avoid special characters in passwords
   - Create databases:
     - asadmin
     - kong
     - keycloak
6. Note the private ip address 

- GLB configuration documentation link
  https://appsentinels.sharepoint.com/:w:/s/CustomerEngagement/EZr4eYihZbpAtW2qm3qjceABHaotB1dkbqtdkLDRgFovdw?e=MHJMeP

## For gcp based deployment 
   For cluster ,alloydb ,internal ip ,bucket and filestore creation refer README in path 'terraform/gcp_terraform'
   1. To connect to cluster run the following command

   ```bash
   gcloud container clusters get-credentials <CLUSTER_NAME> \
   --zone <ZONE> \
   --project <PROJECTID>
   ```

   2. verify number of nodes using following command:

   ```bash
   kubectl get nodes
   ```
   Eg Expected output:
      NAME                                                  STATUS   ROLES    AGE     VERSION
      gke-appsentinels-poc-appsentinels-poc-70246391-5m2z   Ready    <none>   5h14m   v1.35.5-gke.1057002
      gke-appsentinels-poc-appsentinels-poc-70246391-cv9r   Ready    <none>   5h14m   v1.35.5-gke.1057002
      gke-appsentinels-poc-appsentinels-poc-70246391-j7wz   Ready    <none>   5h14m   v1.35.5-gke.1057002


### Notes
- Ensure all components are in the same zone/region for optimal performance
- Database connectivity options (TODO: Document private IP vs public IP considerations)
