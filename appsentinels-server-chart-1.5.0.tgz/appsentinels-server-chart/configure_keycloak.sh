#!/bin/bash
## Runs the Keycloak setup inside the utils pod:
##   1. Waits for the utils pod (and db pod if LOCAL_DB_SERVICE_ENABLED=true) to be Ready
##   2. Copies keycloak_setup.py into the utils pod at /kubernetes-requirements/
##   3. Executes ./kong_config.sh, ./directory_permission.sh, then python3 keycloak_setup.py
##   4. Verifies keycloak.pem, keycloak_user_id.txt, keycloak_client_secret.txt were generated
##   4b. Runs ./kong_jwt.sh (Kong JWT config, uses the generated keycloak.pem)
##   5. Copies those three files out of the pod into ./files/secrets/
##   6. Replaces the hostname and client secret in AUTH_CONFIG
##   7. Deletes and recreates the auth-config-secret
set -e
source ./variables.sh

UTILS_LABEL="app=utils"
DB_LABEL="app=db"
POD_WORKDIR="/kubernetes-requirements"
LOCAL_KEYCLOAK_SCRIPT="./keycloak_setup.py"
SECRETS_DIR="./files/secrets"
WAIT_TIMEOUT="20s"
## Pause (seconds) between each in-pod setup step
STEP_WAIT=10

GENERATED_FILES=("keycloak.pem" "keycloak_user_id.txt" "keycloak_client_secret.txt")

## Resolve a pod name from a label selector
get_pod_name() {
  local label="$1"
  kubectl get pods -n "$NAMESPACE" -l "$label" \
    -o jsonpath="{.items[0].metadata.name}" 2>/dev/null
}

## Wait until at least one pod for the given label is Ready
wait_for_pod() {
  local label="$1"
  echo "==== Waiting for pod ($label) to be Ready (timeout ${WAIT_TIMEOUT}) ===="
  if ! kubectl wait --for=condition=Ready pod -l "$label" \
        -n "$NAMESPACE" --timeout="$WAIT_TIMEOUT"; then
    echo "ERROR: Pod with label '$label' did not become Ready in namespace '$NAMESPACE'"
    exit 1
  fi
}

## ---- 1. Check pod readiness --------------------------------------------------
wait_for_pod "$UTILS_LABEL"

if [ "$LOCAL_DB_SERVICE_ENABLED" == "true" ]; then
  echo "==== LOCAL_DB_SERVICE_ENABLED=true -> also checking db pod ===="
  wait_for_pod "$DB_LABEL"
fi

UTILS_POD=$(get_pod_name "$UTILS_LABEL")
if [ -z "$UTILS_POD" ]; then
  echo "ERROR: No utils pod found with label '$UTILS_LABEL' in namespace '$NAMESPACE'"
  exit 1
fi
echo "==== Using utils pod: $UTILS_POD ===="

## ---- 2. Copy keycloak_setup.py into the utils pod ---------------------------
if [ ! -f "$LOCAL_KEYCLOAK_SCRIPT" ]; then
  echo "ERROR: $LOCAL_KEYCLOAK_SCRIPT not found. Run pre_installation.sh first."
  exit 1
fi
echo "==== Copying keycloak_setup.py to $UTILS_POD:$POD_WORKDIR/ ===="
kubectl cp "$LOCAL_KEYCLOAK_SCRIPT" "$UTILS_POD:$POD_WORKDIR/keycloak_setup.py" -n "$NAMESPACE"

## ---- 3. Execute setup steps inside the pod ----------------------------------
echo "==== Running ./kong_config.sh inside pod ===="
kubectl exec -n "$NAMESPACE" "$UTILS_POD" -- \
  bash -c "cd $POD_WORKDIR && ./kong_config.sh"

echo "==== Waiting ${STEP_WAIT}s before next step ===="
sleep "$STEP_WAIT"

echo "==== Running ./directory_permission.sh inside pod ===="
kubectl exec -n "$NAMESPACE" "$UTILS_POD" -- \
  bash -c "cd $POD_WORKDIR && ./directory_permission.sh"

echo "==== Waiting ${STEP_WAIT}s before next step ===="
sleep "$STEP_WAIT"

echo "==== Running python3 keycloak_setup.py inside pod ===="
kubectl exec -n "$NAMESPACE" "$UTILS_POD" -- \
  bash -c "cd $POD_WORKDIR && python3 keycloak_setup.py"

## ---- 4. Verify the three files were generated -------------------------------
echo "==== Verifying generated files inside pod ===="
for f in "${GENERATED_FILES[@]}"; do
  if ! kubectl exec -n "$NAMESPACE" "$UTILS_POD" -- \
        test -f "$POD_WORKDIR/$f"; then
    echo "ERROR: Expected file '$f' was not generated in $POD_WORKDIR"
    exit 1
  fi
  echo "  found: $f"
done

## ---- 4b. Configure Kong JWT (uses keycloak.pem already in the pod) ----------
echo "==== Waiting ${STEP_WAIT}s before Kong JWT config ===="
sleep "$STEP_WAIT"

echo "==== Running ./kong_jwt.sh inside pod ===="
kubectl exec -n "$NAMESPACE" "$UTILS_POD" -- \
  bash -c "cd $POD_WORKDIR && ./kong_jwt.sh"

## ---- 5. Copy the three files out of the pod into ./files/secrets/ -----------
mkdir -p "$SECRETS_DIR"
for f in "${GENERATED_FILES[@]}"; do
  echo "==== Copying $f out of pod into $SECRETS_DIR/ ===="
  kubectl cp "$UTILS_POD:$POD_WORKDIR/$f" "$SECRETS_DIR/$f" -n "$NAMESPACE"
done

## ---- 6. Replace hostname and client secret in AUTH_CONFIG -------------------
AUTH_CONFIG_FILE="$SECRETS_DIR/AUTH_CONFIG"
if [ ! -f "$AUTH_CONFIG_FILE" ]; then
  echo "ERROR: $AUTH_CONFIG_FILE not found"
  exit 1
fi

CLIENT_SECRET=$(tr -d '\n' < "$SECRETS_DIR/keycloak_client_secret.txt")
## Escape chars that are special in the sed replacement (delimiter '|', '&', '\')
ESCAPED_CLIENT_SECRET=$(printf '%s' "$CLIENT_SECRET" | sed -e 's/[&|\\]/\\&/g')

## Replace the client secret in the "body" field (client_secret=... up to the closing quote)
echo "==== Updating client_secret in AUTH_CONFIG ===="
sed -i -E "s|(client_secret=)[^\"]*|\1${ESCAPED_CLIENT_SECRET}|" "$AUTH_CONFIG_FILE"

## Replace the hostname. Prefer the REPLACE_KEYCLOAK_HOSTNAME placeholder;
## otherwise detect the current hostname from serverUrl and swap it.
if grep -q "REPLACE_KEYCLOAK_HOSTNAME" "$AUTH_CONFIG_FILE"; then
  echo "==== Replacing REPLACE_KEYCLOAK_HOSTNAME with '$HOSTNAME' in AUTH_CONFIG ===="
  sed -i "s|REPLACE_KEYCLOAK_HOSTNAME|$HOSTNAME|g" "$AUTH_CONFIG_FILE"
else
  OLD_HOST=$(sed -n 's|.*"serverUrl": *"https://\([^"/]*\)".*|\1|p' "$AUTH_CONFIG_FILE" | head -n1)
  if [ -n "$OLD_HOST" ] && [ "$OLD_HOST" != "$HOSTNAME" ]; then
    echo "==== Replacing hostname '$OLD_HOST' with '$HOSTNAME' in AUTH_CONFIG ===="
    sed -i "s|$OLD_HOST|$HOSTNAME|g" "$AUTH_CONFIG_FILE"
  elif [ -z "$OLD_HOST" ]; then
    echo "WARNING: could not detect current hostname in AUTH_CONFIG; skipping hostname replace"
  else
    echo "==== Hostname already set to '$HOSTNAME' in AUTH_CONFIG ===="
  fi
fi

## ---- 7. Delete and recreate the auth-config-secret -------------------------
echo "==== Recreating auth-config-secret in namespace '$NAMESPACE' ===="
kubectl delete secret auth-config-secret -n "$NAMESPACE" --ignore-not-found
kubectl create secret generic auth-config-secret \
  --from-file=auth_config="$AUTH_CONFIG_FILE" -n "$NAMESPACE"

echo "==== Keycloak pod setup completed successfully ===="
