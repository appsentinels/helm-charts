#!/bin/bash

source ../../variables.sh

openssl genpkey -algorithm RSA -out tls.key
openssl req -new -key tls.key -out tls.pem -subj "/CN=${HOSTNAME}"
openssl req -x509 -days 365 -key tls.key -in tls.pem -out tls.crt
openssl x509 -in tls.crt -text -noout

sleep 2

echo "==== Creating namespace '$NAMESPACE' ===="
kubectl create namespace "$NAMESPACE"

echo "Creating secret for cluster certificate"
kubectl create secret tls clustercert --cert=./tls.crt --key=./tls.key -n "$NAMESPACE"
