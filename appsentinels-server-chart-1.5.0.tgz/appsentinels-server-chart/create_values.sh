#!/bin/bash
set -euo pipefail

source ./variables.sh

# Decide secured docker login
SECURED_LOGIN_VALUE=false
if [[ -n "${IMAGE_REPO_USERNAME:-}" ]]; then
  SECURED_LOGIN_VALUE=true
fi
# Build ADMIN_DB sed expressions based on GLOBAL_DB is set
if [[ -n "${GLOBAL_DB:-}" ]]; then
  ADMIN_DB_SED='s|.*#REPLACE_ADMIN_DB_BLOCK.*|    - name: ADMIN_DB\n      value: '"$GLOBAL_DB"'|'
  PIISERVER_ENV_SED='s|.*#REPLACE_PIISERVER_ENV_BLOCK.*|  env:\n    - name: ADMIN_DB\n      value: '"$GLOBAL_DB"'|'
else
  ADMIN_DB_SED='/#REPLACE_ADMIN_DB_BLOCK/d'
  PIISERVER_ENV_SED='s|.*#REPLACE_PIISERVER_ENV_BLOCK.*|  env: []|'
fi

# Generate values.yaml: single pass for all standard replacements
sed \
  -e "s|REPLACE_NAMESPACE|$NAMESPACE|g" \
  -e "s|REPLACE_APPSENTINELS_PLATFORM|$HOSTNAME|g" \
  -e "s|REPLACE_RELEASE_VERSION|$RELEASE_VERSION|g" \
  -e "s|REPLACE_LOADBALANCER_IP|$LOADBALANCER_IP|g" \
  -e "s|REPLACE_KONG_SERVICE_TYPE|$KONG_SERVICE_TYPE|g" \
  -e "s|REPLACE_POSTGRES_HOST|$POSTGRES_HOST|g" \
  -e "s|REPLACE_LOCAL_DB_SERVICE_ENABLED|$LOCAL_DB_SERVICE_ENABLED|g" \
  -e "s|REPLACE_SCHEDULER_CLEANCSV_ENABLED|$SCHEDULER_CLEANCSV_ENABLED|g" \
  -e "s|REPLACE_DOCKER_REGISTRY|$IMAGE_REGISTRY|g" \
  -e "s|securedDockerLogin: false|securedDockerLogin: $SECURED_LOGIN_VALUE|g" \
  -e "s|REPLACE_CLOUD_PROVIDER|$CLOUD_PROVIDER|g" \
  -e "s|REPLACE_USE_INTERNAL_IP|$USE_INTERNAL_IP|g" \
  -e "s|REPLACE_GLOBAL_DB|$GLOBAL_DB|g" \
  -e "$ADMIN_DB_SED" \
  -e "$PIISERVER_ENV_SED" \
  ./values.yaml.template > ./.values.yaml.tmp

# Handle optional GCP_BUCKET_NAME
if [ -n "$GCP_BUCKET_NAME" ]; then
  echo "==== GCP Bucket detected: adding bucketClaimName ===="
  sed "s|REPLACE_BUCKET_CLAIM_NAME|bucketClaimName: gcs-bucket-claim|g" ./.values.yaml.tmp > ./values.yaml
else
  echo "==== GCP Bucket name not provided: skipping bucketClaimName ===="
  sed "s|REPLACE_BUCKET_CLAIM_NAME||g" ./.values.yaml.tmp > ./values.yaml
fi

# Clean up intermediate file
rm -f ./.values.yaml.tmp 2>/dev/null || true
