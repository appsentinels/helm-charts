#!/bin/bash
source ./variables.sh

echo "==== Deleting namespace '$NAMESPACE' ===="
kubectl delete namespace "$NAMESPACE"

if [ "$CLOUD_PROVIDER" == "azure" ]; then
  kubectl delete -f ./storage/azure/pvc.yaml 2>/dev/null
  kubectl delete -f ./storage/azure/data_storage_class.yaml 2>/dev/null
  if [ "$LOCAL_DB_SERVICE_ENABLED" == "true" ]; then
    kubectl delete -f ./storage/azure/db-pvc.yaml 2>/dev/null
    kubectl delete -f ./storage/azure/db_storage_class.yaml 2>/dev/null
  fi
elif [ "$CLOUD_PROVIDER" == "aws" ]; then
  kubectl delete -f ./storage/aws/aws-pvc.yaml 2>/dev/null
  kubectl delete -f ./storage/aws/aws-pv.yaml 2>/dev/null
  if [ "$LOCAL_DB_SERVICE_ENABLED" == "true" ]; then
    kubectl delete -f ./storage/aws/aws-db-pvc.yaml 2>/dev/null
    kubectl delete -f ./storage/aws/aws-db-pv.yaml 2>/dev/null
  fi
elif [ "$CLOUD_PROVIDER" == "local" ]; then
  kubectl delete -f ./storage/local/local-pvc.yaml 2>/dev/null
  kubectl delete -f ./storage/local/local-pv.yaml 2>/dev/null
  if [ "$LOCAL_DB_SERVICE_ENABLED" == "true" ]; then
    kubectl delete -f ./storage/local/local-db-pvc.yaml 2>/dev/null
    kubectl delete -f ./storage/local/local-db-pv.yaml 2>/dev/null
  fi
else
  sed "s|REPLACE_NAMESPACE|$NAMESPACE|g" ./storage/common/pvc.yaml | kubectl delete -f - 2>/dev/null
  kubectl delete -f ./storage/common/pv.yaml 2>/dev/null
  if [ "$CLOUD_PROVIDER" == "gcp" ] && [ "$LOCAL_DB_SERVICE_ENABLED" == "true" ]; then
    sed "s|REPLACE_NAMESPACE|$NAMESPACE|g" ./storage/gke/gke-db-pvc.yaml | kubectl delete -f - 2>/dev/null
    kubectl delete -f ./storage/gke/gke-db-pv.yaml 2>/dev/null
  fi
fi
