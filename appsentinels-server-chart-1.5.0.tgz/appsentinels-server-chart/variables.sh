#!/bin/bash
## Hostname / Domain of the cluster
export NAMESPACE="appsentinels"
export HOSTNAME="appsentinels-poc-aks.appsentinels.ai"
## Set the release verion 
export RELEASE_VERSION="26.05.R1"
## IP address to be assigned to kong - Terraform copy kong_site_a_ip or kong_site_b_ip
export LOADBALANCER_IP="34.93.8.113"
# Set to "LoadBalancer" or "ClusterIP" (use ClusterIP when Kong is behind an external LB)
export KONG_SERVICE_TYPE="LoadBalancer"
## Terraform copy alloydb_site_a_ip or alloydb_site_b_ip or from the console copy the primary/ secondary instance ip address
export POSTGRES_HOST="db"
## Filestore ip address & path - Terraform copy filestore_site_a_ip or filestore_site_b_ip
export NFS_SERVER_IP="10.135.113.66"
export NFS_PATH="/data"
# Set to "azure", "aws", "gcp", or "local" (for local disk / hostPath based k8s clusters)
export CLOUD_PROVIDER="gcp"
export USE_INTERNAL_IP="true" # Set to "true" to use internal IP for GCP or "false"
# For DR setup we need dual region bucket to be created in GCP
# Keep empty if not required
# eg. GCP_BUCKET_NAME="appsentinels-bucket-48683d0c"
export GCP_BUCKET_NAME=""
# Host path for local disk storage (only used when CLOUD_PROVIDER="local")
export LOCAL_STORAGE_PATH="/as_platform/k8-storage"
# Set to "true" to enable local db service or "false"
export LOCAL_DB_SERVICE_ENABLED="true"
# Set to "true" to enable the scheduler-cleancsv service (dedicated worker for
# the CleanCsv job, split off from the main scheduler service) or "false"
export SCHEDULER_CLEANCSV_ENABLED="false"
# Set to empty string to disable or provide
export GLOBAL_DB="appsentinels_global"
## Image repository where the image get pulled for each services for eg (docker.io/appsentinelsai/adminapp:main-latest)
export IMAGE_REGISTRY="docker.io/appsentinels"
### Image registry to download image based on username & password (token)
export IMAGE_REPO_USERNAME=""
## Image repo url to create secrets for secure login
export IMAGE_REPO_SERVER="https://index.docker.io/v1/"