#!/bin/bash
set -e
source ./variables.sh
## Run Python script to configure Keycloak
python3 keycloak_setup.py

## Read client secret safely
CLIENT_SECRET=$(cat ./keycloak_client_secret.txt)

## Escape special characters in CLIENT_SECRET for sed
ESCAPED_CLIENT_SECRET=$(printf '%s\n' "$CLIENT_SECRET" | sed -e 's/[\/&]/\\&/g')

## Replace placeholders in AUTH_CONFIG
sed -e "s|REPLACE_KEYCLOAK_HOSTNAME|$HOSTNAME|g" \
    -e "s|REPLACE_KEYCLOAK_CLIENT_SECRET|$ESCAPED_CLIENT_SECRET|g" \
    ./files/secrets/AUTH_CONFIG_TEMPLATE > ./files/secrets/AUTH_CONFIG

## Delete and recreate the AUTH_CONFIG secrets
kubectl delete secret -n "$NAMESPACE" auth-config-secret || true
kubectl create secret generic auth-config-secret --from-file=auth_config=./files/secrets/AUTH_CONFIG -n "$NAMESPACE"

# Copy Keycloak PEM file to utils pod
LABEL_SELECTOR="app=utils"
LOCAL_FILE_PATH="./keycloak.pem"
POD_DEST_PATH="/kubernetes-requirements/"

## Get the running pod name dynamically
POD_NAME=$(kubectl get pods -n "$NAMESPACE" -l "$LABEL_SELECTOR" -o jsonpath="{.items[0].metadata.name}")

if [ -z "$POD_NAME" ]; then
    echo "No running pod found with label $LABEL_SELECTOR in namespace $NAMESPACE"
    exit 1
fi

echo "Copying file to pod: $POD_NAME"

## Copy the file to the pod
kubectl cp "$LOCAL_FILE_PATH" "$POD_NAME:$POD_DEST_PATH" -n "$NAMESPACE"

if [ $? -eq 0 ]; then
    echo "File copied successfully to $POD_NAME:$POD_DEST_PATH"
else
    echo "Failed to copy file"
    exit 1
fi
