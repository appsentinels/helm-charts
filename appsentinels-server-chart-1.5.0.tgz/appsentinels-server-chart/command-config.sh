set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Source namespace and other variables
if [ -f "${SCRIPT_DIR}/variables.sh" ]; then
    # shellcheck disable=SC1091
    source "${SCRIPT_DIR}/variables.sh"
else
    echo "Error: variables.sh not found in ${SCRIPT_DIR}" >&2
    exit 1
fi

if [ -z "${NAMESPACE:-}" ]; then
    echo "Error: NAMESPACE is not set (expected from variables.sh)" >&2
    exit 1
fi

usage() {
    echo "Usage: $0 <keyword> [tail=N]"
    echo ""
    echo "Available keywords:"
    echo "  exec-<service>   Exec into a pod matching <service> (e.g. exec-utils, exec-kong)"
    echo "  <service>-logs   Tail logs for a service (label app=<service>)"
    echo "                   e.g. kong-logs, adminapp-logs"
    echo "                   optional: kong-logs tail=100"
    exit 1
}

if [ $# -lt 1 ]; then
    usage
fi

KEYWORD="$1"
shift || true

# Find a pod by name substring match, first match wins
get_pod_by_name() {
    local service="$1"
    kubectl get pods -n "${NAMESPACE}" --no-headers -o custom-columns=":metadata.name" \
        | grep -i "${service}" \
        | head -n 1
}

cmd_exec_service() {
    local service="$1"
    local pod
    pod="$(get_pod_by_name "${service}")"

    if [ -z "${pod}" ]; then
        echo "Error: no pod matching '${service}' found in namespace '${NAMESPACE}'" >&2
        exit 1
    fi

    echo "Found pod: ${pod} (namespace: ${NAMESPACE})"
    exec kubectl exec -it -n "${NAMESPACE}" "${pod}" -- bash
}

cmd_service_logs() {
    local service="$1"
    shift || true
    local tail_value=""

    # Parse optional tail=N argument(s)
    for arg in "$@"; do
        case "${arg}" in
            tail=*)
                tail_value="${arg#tail=}"
                ;;
            *)
                echo "Warning: ignoring unrecognized argument '${arg}'" >&2
                ;;
        esac
    done

    local cmd=(kubectl logs -f -n "${NAMESPACE}" -l "app=${service}")
    if [ -n "${tail_value}" ]; then
        cmd+=(--tail="${tail_value}")
    fi

    echo "Running: ${cmd[*]}"
    exec "${cmd[@]}"
}

case "${KEYWORD}" in
    exec-*)
        SERVICE="${KEYWORD#exec-}"
        cmd_exec_service "${SERVICE}"
        ;;
    *-logs)
        SERVICE="${KEYWORD%-logs}"
        cmd_service_logs "${SERVICE}" "$@"
        ;;
    *)
        echo "Error: unknown keyword '${KEYWORD}'" >&2
        usage
        ;;
esac

