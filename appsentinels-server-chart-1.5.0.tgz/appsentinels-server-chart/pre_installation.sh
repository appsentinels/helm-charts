#!/bin/bash
## Name space creation was done as part of certifcate creation 
## under files/certs/create_certificate.sh 
set -ex
### create variables
source ./variables.sh

echo "==== Checking if namespace '$NAMESPACE' exists ===="
if ! kubectl get namespace "$NAMESPACE" > /dev/null 2>&1; then
  echo "==== Namespace '$NAMESPACE' not found. Creating namespace '$NAMESPACE' ===="
  kubectl create namespace "$NAMESPACE"
else
  echo "==== Namespace '$NAMESPACE' already exists ===="
fi

if [ "$CLOUD_PROVIDER" == "azure" ]; then
  echo "==== Configuring Storage Class (Azure) ===="
  sed "s|REPLACE_NAMESPACE|$NAMESPACE|g" ./storage/azure/data_storage_class.yaml | kubectl apply -f -
  sleep 2

  if [ "$LOCAL_DB_SERVICE_ENABLED" == "true" ]; then
    echo "==== Configuring DB Storage Class (Azure) ===="
    sed "s|REPLACE_NAMESPACE|$NAMESPACE|g" ./storage/azure/db_storage_class.yaml | kubectl apply -f -
    sleep 2
    echo "==== Configuring DB Persistent Volume Claim (Azure) ===="
    sed "s|REPLACE_NAMESPACE|$NAMESPACE|g" ./storage/azure/db-pvc.yaml | kubectl apply -f -
    sleep 2
  fi

  echo "==== Configuring Persistent Volume Claim (Azure) ===="
  sed "s|REPLACE_NAMESPACE|$NAMESPACE|g" ./storage/azure/pvc.yaml | kubectl apply -f -
  sleep 2
elif [ "$CLOUD_PROVIDER" == "aws" ]; then
  echo "==== Configuring Storage Class (AWS EKS) ===="
  if [ "$LOCAL_DB_SERVICE_ENABLED" == "true" ]; then
  echo "==== Applying DB PV & PVC ===="
  sed "s|REPLACE_NFS_SERVER_IP|$NFS_SERVER_IP|g" \
    ./storage/aws/aws-db-pv.yaml.template > ./storage/aws/aws-db-pv.yaml

  kubectl apply -f ./storage/aws/aws-db-pv.yaml
  sed "s|REPLACE_NAMESPACE|$NAMESPACE|g" ./storage/aws/aws-db-pvc.yaml | kubectl apply -f -
fi

echo "==== Applying Data PV & PVC ===="
sed "s|REPLACE_NFS_SERVER_IP|$NFS_SERVER_IP|g" \
  ./storage/aws/aws-pv.yaml.template > ./storage/aws/aws-pv.yaml

kubectl apply -f ./storage/aws/aws-pv.yaml
sed "s|REPLACE_NAMESPACE|$NAMESPACE|g" ./storage/aws/aws-pvc.yaml | kubectl apply -f -
elif [ "$CLOUD_PROVIDER" == "local" ]; then
  echo "==== Configuring Storage (Local Disk / hostPath) ===="

  if [ "$LOCAL_DB_SERVICE_ENABLED" == "true" ]; then
    echo "==== Applying DB PV (Local) ===="
    sed -e "s|REPLACE_LOCAL_STORAGE_PATH|$LOCAL_STORAGE_PATH|g" \
        -e "s|REPLACE_NAMESPACE|$NAMESPACE|g" \
      ./storage/local/local-db-pv.yaml.template > ./storage/local/local-db-pv.yaml
    kubectl apply -f ./storage/local/local-db-pv.yaml
    sleep 2

    echo "==== Applying DB PVC (Local) ===="
    sed "s|REPLACE_NAMESPACE|$NAMESPACE|g" \
      ./storage/local/local-db-pvc.yaml.template > ./storage/local/local-db-pvc.yaml
    kubectl apply -f ./storage/local/local-db-pvc.yaml
    sleep 2
  fi

  echo "==== Applying Data PV (Local) ===="
  sed -e "s|REPLACE_LOCAL_STORAGE_PATH|$LOCAL_STORAGE_PATH|g" \
      -e "s|REPLACE_NAMESPACE|$NAMESPACE|g" \
    ./storage/local/local-pv.yaml.template > ./storage/local/local-pv.yaml
  kubectl apply -f ./storage/local/local-pv.yaml
  sleep 2

  echo "==== Applying Data PVC (Local) ===="
  sed "s|REPLACE_NAMESPACE|$NAMESPACE|g" \
      ./storage/local/local-pvc.yaml.template > ./storage/local/local-pvc.yaml
  kubectl apply -f ./storage/local/local-pvc.yaml
  sleep 2
else
  # Configure the Persistent Volume
  echo "==== Configuring Persistent Volume (Common) ===="
  sed "s|REPLACE_NFS_SERVER_IP|$NFS_SERVER_IP|g" ./storage/common/pv.yaml.template > ./storage/common/pv.yaml.template.1
  sed "s|REPLACE_NFS_PATH|$NFS_PATH|g" ./storage/common/pv.yaml.template.1 > ./storage/common/pv.yaml

  kubectl apply -f ./storage/common/pv.yaml
  sleep 2

  sed "s|REPLACE_NAMESPACE|$NAMESPACE|g" ./storage/common/pvc.yaml | kubectl apply -f -
  sleep 2
  # GCP Bucket PVC Creation
  ## Skip if GCP_BUCKET_NAME is not provided
  if [ -z "$GCP_BUCKET_NAME" ]; then
    echo "==== GCP Bucket name not provided. Skipping GCP Bucket PVC creation ===="
  else
    echo "==== Configuring GCP Bucket Persistent Volume Claim ===="
    sed "s|REPLACE_GCP_BUCKET_NAME|$GCP_BUCKET_NAME|g" ./storage/common/gcs-bucket-pv.yaml.template > ./storage/common/gcs-bucket-pv.yaml

    kubectl apply -f ./storage/common/gcs-bucket-pv.yaml
    sleep 2

    kubectl apply -f ./storage/common/gcs-bucket-pvc.yaml
    sleep 2
  fi

  ## In case of GKE and Local DB service is enabled, create a separate PVC for DB
  if [ "$CLOUD_PROVIDER" == "gcp" ] && [ "$LOCAL_DB_SERVICE_ENABLED" == "true" ]; then
    echo "==== Applied Persistent Volume Claim for DB (GKE) ===="
    sed "s|REPLACE_NFS_SERVER_IP|$NFS_SERVER_IP|g" ./storage/gke/gke-db-pv.yaml.template > ./storage/gke/gke-db-pv.yaml.template.1
    sed "s|REPLACE_NFS_PATH|$NFS_PATH|g" ./storage/gke/gke-db-pv.yaml.template.1 > ./storage/gke/gke-db-pv.yaml
    kubectl apply -f ./storage/gke/gke-db-pv.yaml
    sleep 2
    echo "==== Configuring Persistent Volume Claim for DB (GKE) ===="
    sed "s|REPLACE_NAMESPACE|$NAMESPACE|g" ./storage/gke/gke-db-pvc.yaml | kubectl apply -f -
    sleep 2
  fi
fi


echo "==== Replacing hostname ====="
KEYCLOAK_ADMIN_PASSWORD=$(tr -d '\n' < ./files/secrets/KEYCLOAK_ADMIN_PASSWORD)
sed "s|REPLACE_APPSENTINELS_PLATFORM|$HOSTNAME|g;s|REPLACE_KEYCLOAK_ADMIN_PASSWORD|$KEYCLOAK_ADMIN_PASSWORD|g" ./keycloakTemplate.py > ./keycloak_setup.py
DEVOPS_PASSWORD=$(tr -d '\n' < ./files/secrets/DEVOPS_PASSWORD)

## command to remove new line to password secret files
tr -d '\n' < ./files/secrets/DEVOPS > ./files/secrets/DEVOPS.clean
mv ./files/secrets/DEVOPS.clean ./files/secrets/DEVOPS

sed -i "s|<DEVOPS_PASSWORD>|$DEVOPS_PASSWORD|g" ./files/secrets/DEVOPS

echo "==== Creating Secrets ===="
kubectl create secret generic devops-secret --from-file=devops_connection=./files/secrets/DEVOPS -n "$NAMESPACE"
kubectl create secret generic devops-password-secret --from-literal=devops_password="$DEVOPS_PASSWORD" -n "$NAMESPACE"
kubectl create secret generic auth-config-secret --from-file=auth_config=./files/secrets/AUTH_CONFIG -n "$NAMESPACE"
kubectl create secret generic support-list --from-file=support_list=./files/secrets/SUPPORT_LIST.json -n "$NAMESPACE"
kubectl create secret generic keycloak-certs --from-file=tls.crt=./files/certs/tls.crt --from-file=tls.key=./files/certs/tls.key -n "$NAMESPACE"
kubectl create secret generic keycloak-admin-password-secret --from-literal=keycloak_admin_password="$KEYCLOAK_ADMIN_PASSWORD" -n "$NAMESPACE"
kubectl create secret generic clickhouse-password-secret --from-file=clickhouse_password=./files/secrets/CLICKHOUSE_PASSWORD -n "$NAMESPACE"
## Create RDS CA secret (AWS only)
if [[ "$CLOUD_PROVIDER" == "aws" ]]; then
  echo "==== Downloading RDS CA bundle ===="

  curl -fsSL \
    https://truststore.pki.rds.amazonaws.com/global/global-bundle.pem \
    -o rds-combined-ca-bundle.pem

  echo "==== Creating/Updating RDS CA secret ===="

  kubectl create secret generic rds-ca-cert \
    --from-file=rds-ca.pem=rds-combined-ca-bundle.pem \
    -n "$NAMESPACE" \
    --dry-run=client -o yaml | kubectl apply -f -

  rm -f rds-combined-ca-bundle.pem
fi
### For Image repo secure login
##TODO docker-registry username/password to be changed accordingly
if [ -n "$IMAGE_REPO_USERNAME" ]; then
  IMAGE_REPO_TOKEN=$(cat ./files/secrets/IMAGE_REPO_TOKEN)
  kubectl create secret docker-registry docker-hub-secret \
    --docker-server=$IMAGE_REPO_SERVER \
    --docker-username="$IMAGE_REPO_USERNAME" \
    --docker-password="$IMAGE_REPO_TOKEN" \
    -n "$NAMESPACE"
fi
echo "==== Creating Values.yaml file ===="
bash ./create_values.sh

### GCS Fuse setup for Disaster Recovery (GCP only)
## If a GCP Bucket is used for DR, enable GCS Fuse at the GKE cluster level
## so pods can mount GCS buckets directly for read/write operations.
if [ "$CLOUD_PROVIDER" == "gcp" ]; then
  echo "==== Configuring GCS Fuse support (GKE) ===="

  ## Derive cluster name, region/location and project id from the current context.
  ## GKE kubectl contexts are named: gke_<PROJECT_ID>_<LOCATION>_<CLUSTER_NAME>
  CURRENT_CONTEXT=$(kubectl config current-context)
  PROJECT_ID=$(echo "$CURRENT_CONTEXT" | cut -d'_' -f2)
  REGION=$(echo "$CURRENT_CONTEXT" | cut -d'_' -f3)
  CLUSTER_NAME=$(echo "$CURRENT_CONTEXT" | cut -d'_' -f4-)

  ## Fall back to gcloud config for the project id if it could not be parsed.
  if [ -z "$PROJECT_ID" ]; then
    PROJECT_ID=$(gcloud config get-value project 2>/dev/null)
  fi

  echo "==== Detected CLUSTER_NAME=$CLUSTER_NAME REGION=$REGION PROJECT_ID=$PROJECT_ID ===="

  ## 1. Enable GCS Fuse CSI Driver on the GKE cluster
  gcloud container clusters update "$CLUSTER_NAME" \
    --region "$REGION" \
    --update-addons=GcsFuseCsiDriver=ENABLED

  ## 2. Create a GCP IAM service account for GCS Fuse access (skip if it exists)
  if ! gcloud iam service-accounts describe \
    "gcs-fuse-access@${PROJECT_ID}.iam.gserviceaccount.com" >/dev/null 2>&1; then
    gcloud iam service-accounts create gcs-fuse-access \
      --display-name="GCS Fuse Access for GKE"
  fi

  ## 3. Grant Storage Object Admin on the service account
  gcloud projects add-iam-policy-binding "$PROJECT_ID" \
    --member="serviceAccount:gcs-fuse-access@${PROJECT_ID}.iam.gserviceaccount.com" \
    --role="roles/storage.objectAdmin"

  ## 4. Create the Kubernetes service account (skip if it exists)
  if ! kubectl get serviceaccount gcs-fuse-sa -n "$NAMESPACE" >/dev/null 2>&1; then
    kubectl create serviceaccount gcs-fuse-sa -n "$NAMESPACE"
  fi

  ## 5. Annotate the KSA to link it with the GCP IAM service account (Workload Identity)
  kubectl annotate serviceaccount gcs-fuse-sa \
    -n "$NAMESPACE" \
    "iam.gke.io/gcp-service-account=gcs-fuse-access@${PROJECT_ID}.iam.gserviceaccount.com" \
    --overwrite

  ## 6. Bind Workload Identity so the KSA can impersonate the GCP IAM service account
  gcloud iam service-accounts add-iam-policy-binding \
    "gcs-fuse-access@${PROJECT_ID}.iam.gserviceaccount.com" \
    --member="serviceAccount:${PROJECT_ID}.svc.id.goog[${NAMESPACE}/gcs-fuse-sa]" \
    --role="roles/iam.workloadIdentityUser"

  ## 7. Verify the service account mapping
  echo "==== Verifying GCS Fuse service account mapping ===="
  kubectl get serviceaccount gcs-fuse-sa -n "$NAMESPACE" -o yaml
fi

set +ex
