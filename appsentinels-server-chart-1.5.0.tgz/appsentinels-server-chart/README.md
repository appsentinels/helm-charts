# AppSentinels Platform — Helm Installation

## TL;DR — Installation Steps

**Before you start**, provision the following infra:
- A Kubernetes cluster with appropriately sized nodes
- A static public IP mapped to your DNS hostname
- A shared NFS disk for platform data
- A PostgreSQL instance (managed or local)
- TLS certificates (self-signed or signed) matching your hostname

**Step 1 — Fill in `variables.sh`**
Set your hostname, load balancer IP, NFS details, postgres host, and cloud provider.

**Step 2 — Run `pre_installation.sh`**
Creates the namespace, PVCs, and all Kubernetes secrets including certs and DB passwords.

**Step 3 — Helm install Stage 1**
Brings up Kong, Keycloak, and Utils only. Verify all three pods are running.

**Step 4 — Configure Kong**
Exec into the utils pod and run `kong_config.sh` to set up Kong routes and services.

**Step 5 — Configure Keycloak**
Run `keycloak_setup.py` to set up the auth realm. This generates the client secret and Keycloak PEM. Update the auth config secret in Kubernetes.

**Step 6 — Configure Kong JWT**
Copy the Keycloak PEM into the utils pod and run `kong_jwt.sh` to wire up JWT validation.

**Step 7 — Helm install Stage 2**
Uninstall Stage 1 and do a fresh `helm install` with Stage 2 enabled. This brings up the full platform.

**Step 8 — Create Org and Users**
Exec into utils and run `default_user_org.sh`. Note down the API key for the controller.

**Step 9 — Upload License**
Log into the UI and upload the license file under Settings.

---

For detailed cloud-specific setup refer to `gke_k8_setup.md`, `aks_k8_setup.md`, or `aws_k8_setup.md` and then `helm_installation.md`.