import http
import requests

keycloakUrl = 'http://keycloak:8080'
redirectUrl = 'https://REPLACE_APPSENTINELS_PLATFORM/*'

adminUser = "admin"
adminPasswd = "REPLACE_KEYCLOAK_ADMIN_PASSWORD"

masterRealm = "master"
appsenRealm = "Appsentinels"

SUPPORTUSERID = "support@appsentinels.ai"
SUPPORTUSERNAME = "Support"
SUPPORTPASSWD = "Support#21"

accessToken = ""
publicKey = ""
userID = ""
clientSecret = ""


def getToken(realm_name, username, password):
    url = keycloakUrl + "/auth/realms/{}/protocol/openid-connect/token".format(realm_name)
    params = {'username': username, 'password': password, 'grant_type': 'password', 'client_id': 'admin-cli'}
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    resp = requests.post(url, data=params, headers=headers, verify=False)

    if resp.status_code != http.HTTPStatus.OK:
        print("ERROR# Status code: {}, Response: {}".format(resp.status_code, resp.text))
        exit()

    return resp.json().get("access_token")


def getHeaders():
    return {'Authorization': "Bearer {}".format(accessToken), 'Content-Type': 'application/json'}


def check_status(fn_name, resp, exp_code):
    if resp.status_code != exp_code:
        print("{} ERROR# Status code: {}, Expected Resp Code: {}, Response: {}".format(fn_name, resp.status_code,
                                                                                       exp_code, resp.text))
        exit()


def createRealm(realm_name):
    url = keycloakUrl + "/auth/admin/realms"
    params = {"realm": realm_name, "enabled": True}

    resp = requests.post(url, json=params, headers=getHeaders(), verify=False)
    check_status("createRealm", resp, http.HTTPStatus.CREATED)


def createClient(realm_name):
    url = keycloakUrl + "/auth/admin/realms/{}/clients".format(realm_name)
    params = {
        "clientId": "frontend",
        "enabled": True,
        "implicitFlowEnabled": True,
        "standardFlowEnabled": True,
        "redirectUris": [redirectUrl],
        "webOrigins": ["*"],
        "publicClient": True
    }
    resp = requests.post(url, json=params, headers=getHeaders(), verify=False)
    check_status("createClient", resp, http.HTTPStatus.CREATED)


def getPublicKey(realm_name):
    url = keycloakUrl + "/auth/realms/{}".format(realm_name)
    resp = requests.get(url, headers=getHeaders(), verify=False)
    check_status("getPublicKey", resp, http.HTTPStatus.OK)

    key = resp.json().get("public_key")
    publickey = "-----BEGIN PUBLIC KEY-----\n" + key + "\n-----END PUBLIC KEY-----"
    return publickey


def createUser(realm_name, username, userid):
    url = keycloakUrl + "/auth/admin/realms/{}/users".format(realm_name)
    params = {
        "username": userid,
        "enabled": True,
        "emailVerified": True,
        "firstName": username,
        "email": userid
    }
    resp = requests.post(url, json=params, headers=getHeaders(), verify=False)
    check_status("createUser", resp, http.HTTPStatus.CREATED)


def getUserID(realm_name, userid):
    url = keycloakUrl + "/auth/admin/realms/{}/users".format(realm_name)
    resp = requests.get(url, headers=getHeaders(), verify=False)
    check_status("getUserID", resp, http.HTTPStatus.OK)

    usersData = resp.json()
    for user in usersData:
        if user.get("username") == userid:
            return user.get("id")

    print("Error: Support user not found")
    exit()


def setUserPasswd(realm_name, user_id, passwd):
    url = keycloakUrl + "/auth/admin/realms/{}/users/{}/reset-password".format(realm_name, user_id)
    params = {"type": "password", "temporary": True, "value": passwd}

    resp = requests.put(url, json=params, headers=getHeaders(), verify=False)
    check_status("setUserPasswd", resp, http.HTTPStatus.NO_CONTENT)


def getClientID(realm_name, client_name):
    url = keycloakUrl + "/auth/admin/realms/{}/clients".format(realm_name)
    resp = requests.get(url, headers=getHeaders(), verify=False)
    check_status("getClientID", resp, http.HTTPStatus.OK)

    clientList = resp.json()
    for client in clientList:
        if client.get("clientId") == client_name:
            return client.get("id")


def updateClientAccessType(realm_name, client_id):
    url = keycloakUrl + "/auth/admin/realms/{}/clients/{}".format(realm_name, client_id)
    params = {
        "enabled": True,
        "publicClient": False,
        "serviceAccountsEnabled": True
    }

    resp = requests.put(url, json=params, headers=getHeaders(), verify=False)
    check_status("updateClientAccessType", resp, http.HTTPStatus.NO_CONTENT)


def getClientSecret(realm_name, client_id):
    url = keycloakUrl + "/auth/admin/realms/{}/clients/{}/client-secret".format(realm_name, client_id)
    resp = requests.get(url, headers=getHeaders(), verify=False)
    check_status("getClientSecret", resp, http.HTTPStatus.OK)
    return resp.json().get("value")


def getServiceUserID(realm_name, client_id):
    url = keycloakUrl + "/auth/admin/realms/{}/clients/{}/service-account-user".format(realm_name, client_id)
    resp = requests.get(url, headers=getHeaders(), verify=False)
    check_status("getServiceUserID", resp, http.HTTPStatus.OK)
    return resp.json().get("id")


def getRoleDetails(realm_name, service_user_id, client_realm_id):
    url = keycloakUrl + "/auth/admin/realms/{}/users/{}/role-mappings/clients/{}/available".format(realm_name,
                                                                                                   service_user_id,
                                                                                                   client_realm_id)
    resp = requests.get(url, headers=getHeaders(), verify=False)
    check_status("getRoleDetails", resp, http.HTTPStatus.OK)

    rolesToAdd = []
    rolesRequired = ["view-users", "query-users", "manage-users"]

    rolesList = resp.json()
    for role in rolesList:
        if role.get("name") in rolesRequired:
            rolesToAdd.append(role)
    return rolesToAdd


def addRolesToServiceAccount(realm_name, service_user_id, client_realm_id, roles_details):
    url = keycloakUrl + "/auth/admin/realms/{}/users/{}/role-mappings/clients/{}".format(realm_name, service_user_id,
                                                                                         client_realm_id)
    resp = requests.post(url, json=roles_details, headers=getHeaders(), verify=False)
    check_status("addRolesToServiceAccount", resp, http.HTTPStatus.NO_CONTENT)


def getAddedRolesDetails(realm_name, service_user_id, client_realm_id):
    url = keycloakUrl + "/auth/admin/realms/{}/users/{}/role-mappings/clients/{}/composite".format(realm_name,
                                                                                                   service_user_id,
                                                                                                   client_realm_id)
    resp = requests.get(url, headers=getHeaders(), verify=False)
    check_status("getAddedRolesDetails", resp, http.HTTPStatus.OK)
    return resp.json()


def createRealmAndClient(realm_name):
    createRealm(realm_name)
    createClient(realm_name)
    return getPublicKey(realm_name)


def createDefaultUser(realm_name, username, userid, passwd):
    createUser(realm_name, username, userid)
    user_id = getUserID(realm_name, userid)
    setUserPasswd(realm_name, user_id, passwd)
    return user_id


def setAccessTypeConfidential(master_realm):
    admin_cli_client_id = getClientID(master_realm, "admin-cli")
    updateClientAccessType(master_realm, admin_cli_client_id)
    client_secret = getClientSecret(master_realm, admin_cli_client_id)
    return client_secret


def addRoles(master_realm, appsen_realm):
    client_realm_id = getClientID(master_realm, "admin-cli")
    serviceUserID = getServiceUserID(master_realm, client_realm_id)
    clientRealmID = getClientID(master_realm, appsen_realm)
    rolesToAdd = getRoleDetails(master_realm, serviceUserID, clientRealmID)

    addRolesToServiceAccount(master_realm, serviceUserID, clientRealmID, rolesToAdd)


def writeToFile(filename, content):
    file = open(filename, "w")
    file.write(content)
    file.close()


if __name__ == "__main__":
    # Get Accession token for admin user
    accessToken = getToken(masterRealm, adminUser, adminPasswd)

    # Get the RS256 Public Key of AppSentinels Realm
    publicKey = createRealmAndClient(appsenRealm)

    # Create the default user in the keycloak for the first time use
    userID = createDefaultUser(appsenRealm, SUPPORTUSERNAME, SUPPORTUSERID, SUPPORTPASSWD)

    # Se the Access type to confidential for admin-cli client and get the secret key for further logins
    clientSecret = setAccessTypeConfidential(masterRealm)

    # Add the view, query & manage user roles for Appsentinels-relam
    addRoles(masterRealm, appsenRealm + "-realm")

    # Write values to the file
    writeToFile("keycloak.pem", publicKey)
    writeToFile("keycloak_client_secret.txt", clientSecret)
    writeToFile("keycloak_user_id.txt", userID)

