# Helm based Server Installation Guide

## Prerequisites

### Certificate Setup
1. Navigate to `./files/certs`
2. Run `create_certificate.sh` to generate:
   - tls.key
   - tls.pem
   - tls.crt
   
Note: This script also creates a cert secret in Kubernetes and also creates the namespace (configured via `NAMESPACE` in `variables.sh`)

To rotate certificates on an already-running cluster, see [docs/certificate-rotation.md](./docs/certificate-rotation.md).

### Secret Configuration
1. Navigate to `./files/secrets`
2. Update the following files (make sure there are no spaces or newlines):
   - `DEVOPS`: Update the Database IP address only — replace `<POSTGRES_HOST>` with the actual host. The password placeholder `<DEVOPS_PASSWORD>` is substituted automatically from `DEVOPS_PASSWORD` at install time.
   - `DEVOPS_PASSWORD`: Set the devops user's database password. This is used to populate the connection string in `DEVOPS` and is also mounted separately as a Kubernetes secret (`devops-password-secret`).
   - `KEYCLOAK_ADMIN_PASSWORD`: Set the Keycloak admin console password.
3. Update `IMAGE_REPO_TOKEN` with the password or token from the Docker Hub settings page (optional).

## Installation Steps

### 1. Pre-Installation Configuration
1. Go back to the top level directory. Open `variables.sh` and configure:
   - NAMESPACE - Kubernetes namespace for the deployment (default: `appsentinels`)
   - RELEASE_VERSION - Image tag used for all services (sets `global.defaultTag` in the generated `values.yaml`, e.g. `26.05.R1`)
   - CLOUD_PROVIDER - `azure`, `aws`, `gcp`, or `local`. When set to `gcp`, `pre_installation.sh` also configures GCS Fuse automatically (see below)
   - nfs_server_ip
   - nfs_path
   - hostname
   - loadbalancer_ip
   - postgres_host
   - IMAGE_REGISTRY - Image registry to be set by default docker.io/appsentinels
   - IMAGE_REPO_USERNAME - provide the username for secured login
   - IMAGE_REPO_SERVER - Provide the docker hub server url for secured login
2. For a Disaster Recovery (DR) setup, provide the GCP_BUCKET_NAME to store common files accessible across regions.
3. To ensure only one active setup (region) at a time, create an external static IP address and set USE_INTERNAL_IP to false, as private IP access is not possible in this configuration.


2. Run `pre_installation.sh`. This script also creates namespace `appsentinels`
   - Install dos2unix and run the following to remove trailing spaces and extra characters: `dos2unix pre_installation.sh variables.sh`


### 2. Verify Resources
1. Check namespace creation (created by `create_certificate.sh` or `pre_installation.sh` using the `NAMESPACE` variable from `variables.sh`)

2. Verify PVC status:
```bash
kubectl get pv,pvc -n $NAMESPACE
```
Eg Expected output:

    NAME         STATUS   VOLUME    CAPACITY   ACCESS MODES   STORAGECLASS   VOLUMEATTRIBUTESCLASS   AGE
    data-claim   Bound    data-pv   1Ti        RWX            manual         <unset>                 8m49s

Note: Capacity here is indicative and may not be actual

Note: DB storage (PV/PVC) is only provisioned when `LOCAL_DB_SERVICE_ENABLED="true"` (local database). When using a managed database (e.g., RDS, Cloud SQL, Azure Database for PostgreSQL), only the data storage is created — no `db-claim` PVC will appear.

3. Verify PV status:
```bash
kubectl get pv -n $NAMESPACE
```

4. Verify secrets:
```bash
kubectl get secrets -n $NAMESPACE
```
Expected secrets include: `devops-secret` (connection string), `devops-password-secret` (password), `keycloak-admin-password-secret`, `auth-config-secret`, `support-list`, `keycloak-certs`, `clickhouse-password-secret`.


### GCS Fuse Setup for Disaster Recovery (GCP)

If a **GCP Bucket** is used for Disaster Recovery (DR) purposes, pods must be able to mount GCS buckets directly for read/write operations, which requires **GCS Fuse** at the GKE cluster level.

**This is now automated by `pre_installation.sh`.** When `CLOUD_PROVIDER="gcp"`, the script automatically:
1. Enables the **GCS Fuse CSI Driver** addon on the cluster
2. Creates the `gcs-fuse-access` GCP IAM service account (if missing)
3. Grants it `roles/storage.objectAdmin`
4. Creates the `gcs-fuse-sa` Kubernetes service account in `$NAMESPACE` (if missing)
5. Annotates the KSA for **Workload Identity**
6. Binds `roles/iam.workloadIdentityUser` between the KSA and the GCP IAM service account
7. Prints the KSA for verification

The cluster name, region, and project ID are derived automatically from your current `kubectl` context (`gke_<PROJECT_ID>_<LOCATION>_<CLUSTER_NAME>`). Ensure the correct context is active before running `pre_installation.sh`:

```bash
kubectl config current-context
gcloud config get-value project
```

> No manual `gcloud`/`kubectl` steps are needed for GCS Fuse. If you need to run them by hand (e.g. debugging), refer to the equivalent commands in the "GCS Fuse setup" block of `pre_installation.sh`.

---

### 3. Stage 1 Installation
```bash
helm install <release> . --set stage1.enabled=true
```
Verify that pods kong, keycloak and utils are running fine. kong-migration should have run successfully atleast once
```bash
kubectl get pods -n $NAMESPACE
NAME                              READY   STATUS             RESTARTS        AGE
keycloak-local-b977f4678-4xvtz    1/1     Running            0               14m
kong-5977c454cf-5bdnd             1/1     Running            0               14m
kong-migrations-fc957bc8f-sqstf   0/1     Completed          7 (3m17s ago)   14m
utils-697c85575-r2lzs             1/1     Running            0               14m
```
---

### AWS Setup – Managed PostgreSQL (RDS)

When running the setup on AWS using an RDS PostgreSQL instance, the initial databases must be created manually.

#### Step 1: Access the Utils Pod

Log in to the utils pod using the following command:

```bash
kubectl exec -it utils-<container-id> -- bash
```

#### Step 2: Connect to the RDS Database

Inside the utils container, connect to the RDS instance using `psql`:

```bash
psql "host=<rds_endpoint> \
      port=5432 \
      user=appsentinels_admin \
      dbname=appsentinels \
      sslmode=verify-full \
      sslrootcert=/run/secrets/db-ca.crt"
```

Replace `<rds_endpoint>`, `user`, and `dbname` as required. (Default Username, Database & Password are created as part of terraform script)

#### Step 3: Create Required Databases

## for gcp using alloydb
1. run ./db_setup.sh inside utils in location `/kubernetes-requirements` 
2. Then proceed to step 5 directly all the database will be created by the script in the alloydb

## for local
After successfully connecting, create the following databases:

```bash
CREATE DATABASE appsentinels_global;
```

#### Step 4: Create Users and Assign Roles

**Create the asadmin user:**

```bash
CREATE USER asadmin WITH LOGIN PASSWORD 'password';
```

**Grant database creation privileges and associate the required role:**

```bash
ALTER ROLE asadmin CREATEDB;
```

#### Step 5: Restart Application Pods

Exit the utils container and delete the **Keycloak** and **Kong** pods so they reconnect to the database using the newly created databases and roles.

#### Step 6: Verify Connectivity

Ensure that all components establish a successful database connection and are running as expected.

---

### 4. Database Setup (AlloyDB / managed PostgreSQL)

Create the default databases and users **before** running the Keycloak/Kong configuration, since Keycloak needs the database to be ready.

#### If AlloyDB is configured (Terraform)
1. **Exec** into the `utils` container.
2. Navigate to the directory: `/kubernetes-requirements`.
3. Run the bash script: `./db_setup.sh`.
4. The script will create the default user (**asadmin**) and default database (**appsentinels_global**).
5. When executing the script, it will prompt for the **AlloyDB IP address** (retrieve this from the Terraform output or `variables.sh`).

   * Use **`postgres`** as the username (created by default through Terraform).
   * Retrieve the **password** from Terraform, as it is also created by default.
   * Once authenticated, the script will prompt for passwords for **asadmin** — use the same passwords as specified in the **secrets file**.

For AWS RDS, follow the "AWS Setup – Managed PostgreSQL (RDS)" section above to create the databases.

### 5. Keycloak & Kong Configuration (automated)

Wait for Keycloak to start and complete verification (~2 minutes) and ensure the server hostname is resolvable, then run the automated setup from the top-level directory:

```bash
./configure_keycloak.sh
```

This script performs all of the previously manual Keycloak/Kong steps end-to-end:
1. Waits for the `utils` pod (and the `db` pod when `LOCAL_DB_SERVICE_ENABLED="true"`) to be Ready
2. Copies `keycloak_setup.py` into the utils pod and runs `./kong_config.sh`, `./directory_permission.sh`, then `python3 keycloak_setup.py`
3. Verifies that `keycloak.pem`, `keycloak_user_id.txt`, and `keycloak_client_secret.txt` were generated
4. Runs `./kong_jwt.sh` (Kong JWT config, using the generated `keycloak.pem`)
5. Copies the three generated files out into `./files/secrets/`
6. Substitutes the hostname and client secret into `AUTH_CONFIG`
7. Deletes and recreates the `auth-config-secret`

After it completes, verify the Kong service LoadBalancer IP:
```bash
kubectl get svc -n $NAMESPACE | grep LoadBalancer
```

> Note: `configure_keycloak.sh` runs `kong_config.sh`, `keycloak_setup.py`, `kong_jwt.sh`, and `directory_permission.sh` for you — you no longer need to `exec` into the utils pod to run these individually.

### 6. Restart Cluster
1. Bring down the cluster for a clean start:
```bash
helm uninstall <release>
```

2. Bring up the cluster with both stages:
```bash
helm install <release> . --set stage2.enabled=true
```

### 7. Create users and demo organization
1. Exec into utils and navigate to `/kubernetes-requirements`
2. Run below for creating a demo org and an associated org admin `demo@appsentinels.ai`:
   ```bash
      ./default_user_org.sh 
   ```
3. Note down the API key for a demo controller

### 8. Restart the adminapp pod
1. kubectl delete pod <adminapp pod name> -n $NAMESPACE

## DB Migration Process
1. Run `helm upgrade <release> . --set db_migration.enabled=true`
2. Copy migration script into utils pod and run it from there

## Kafka Maintenance
1. Run `helm upgrade <release> . --set kafka_care.enabled=true`
2. Perform any maintenance tasks as needed from kafka pod

--- 

### TODO
- ~~Namespace is not configurable~~ (Done: namespace is now configurable via `NAMESPACE` in `variables.sh`)
