#!/bin/bash
## Name space creation was done as part of certifcate creation 
## under files/certs/create_certificate.sh 
set -ex
### create variables
source ./variables.sh

echo "==== Checking if namespace 'appsentinels' exists ===="
if ! kubectl get namespace appsentinels > /dev/null 2>&1; then
  echo "==== Namespace 'appsentinels' not found. Creating namespace 'appsentinels' ===="
  kubectl create namespace appsentinels
else
  echo "==== Namespace 'appsentinels' already exists ===="
fi

if [ "$CLOUD_PROVIDER" == "azure" ]; then
  echo "==== Configuring Storage Class (Azure) ===="
  kubectl apply -f ./storage/azure/data_storage_class.yaml
  sleep 2

  if [ "$LOCAL_DB_SERVICE_ENABLED" == "true" ]; then
    echo "==== Configuring Storage Class (Azure) ===="
    kubectl apply -f ./storage/azure/db_storage_class.yaml
    sleep 2
  fi

  echo "==== Configuring Persistent Volume Claim (Azure) ===="
  kubectl apply -f ./storage/azure/pvc.yaml
  sleep 2
elif [ "$CLOUD_PROVIDER" == "aws" ]; then
  echo "==== Configuring Storage Class (AWS EKS) ===="
  if [ "$LOCAL_DB_SERVICE_ENABLED" == "true" ]; then
  echo "==== Applying DB PV & PVC ===="
  sed "s|REPLACE_NFS_SERVER_IP|$NFS_SERVER_IP|g" \
    ./storage/aws/aws-db-pv.yaml.template > ./storage/aws/aws-db-pv.yaml

  kubectl apply -f ./storage/aws/aws-db-pv.yaml
  kubectl apply -f ./storage/aws/aws-db-pvc.yaml
fi

echo "==== Applying Data PV & PVC ===="
sed "s|REPLACE_NFS_SERVER_IP|$NFS_SERVER_IP|g" \
  ./storage/aws/aws-pv.yaml.template > ./storage/aws/aws-pv.yaml

kubectl apply -f ./storage/aws/aws-pv.yaml
kubectl apply -f ./storage/aws/aws-pvc.yaml
else
  # Configure the Persistent Volume
  echo "==== Configuring Persistent Volume (Common) ===="
  sed "s|REPLACE_NFS_SERVER_IP|$NFS_SERVER_IP|g" ./storage/common/pv.yaml.template > ./storage/common/pv.yaml.template.1
  sed "s|REPLACE_NFS_PATH|$NFS_PATH|g" ./storage/common/pv.yaml.template.1 > ./storage/common/pv.yaml

  kubectl apply -f ./storage/common/pv.yaml
  sleep 2

  kubectl apply -f ./storage/common/pvc.yaml
  sleep 2

  if [ "$LOCAL_DB_SERVICE_ENABLED" == "true" ]; then
    echo "!!!!!!! Local DB Service support is pending for this cloud provider. Exiting. !!!!!!!"
    exit 1
  fi
fi


echo "==== Replacing hostname ====="
sed "s|REPLACE_APPSENTINELS_PLATFORM|$HOSTNAME|g" ./keycloakTemplate.py > ./keycloak_setup.py
## command to remove new line to password secret files
tr -d '\n' < ./files/secrets/POSTGRES_PASSWORD > ./files/secrets/POSTGRES_PASSWORD.clean
mv ./files/secrets/POSTGRES_PASSWORD.clean ./files/secrets/POSTGRES_PASSWORD

tr -d '\n' < ./files/secrets/DEVOPS > ./files/secrets/DEVOPS.clean
mv ./files/secrets/DEVOPS.clean ./files/secrets/DEVOPS

echo "==== Creating Secrets ===="
kubectl create secret generic devops-secret --from-file=devops_connection=./files/secrets/DEVOPS -n appsentinels
kubectl create secret generic kong-postgres-password-secret --from-file=kong_postgres_password=./files/secrets/POSTGRES_PASSWORD -n appsentinels
kubectl create secret generic auth-config-secret --from-file=auth_config=./files/secrets/AUTH_CONFIG -n appsentinels
kubectl create secret generic support-list --from-file=support_list=./files/secrets/SUPPORT_LIST.json -n appsentinels
kubectl create secret generic keycloak-certs --from-file=tls.crt=./files/certs/tls.crt --from-file=tls.key=./files/certs/tls.key -n appsentinels
## Create RDS CA secret (AWS only)
if [[ "$CLOUD_PROVIDER" == "aws" ]]; then
  echo "==== Downloading RDS CA bundle ===="

  curl -fsSL \
    https://truststore.pki.rds.amazonaws.com/global/global-bundle.pem \
    -o rds-combined-ca-bundle.pem

  echo "==== Creating/Updating RDS CA secret ===="

  kubectl create secret generic rds-ca-cert \
    --from-file=rds-ca.pem=rds-combined-ca-bundle.pem \
    -n appsentinels \
    --dry-run=client -o yaml | kubectl apply -f -

  rm -f rds-combined-ca-bundle.pem
fi
### For Image repo secure login
##TODO docker-registry username/password to be changed accordingly
if [ -n "$IMAGE_REPO_USERNAME" ]; then
  IMAGE_REPO_TOKEN=$(cat ./files/secrets/IMAGE_REPO_TOKEN)
  kubectl create secret docker-registry docker-hub-secret \
    --docker-server=$IMAGE_REPO_SERVER \
    --docker-username="$IMAGE_REPO_USERNAME" \
    --docker-password="$IMAGE_REPO_TOKEN" \
    -n appsentinels
fi
echo "==== Creating Values.yaml file ===="
bash ./create_values.sh
set +ex
